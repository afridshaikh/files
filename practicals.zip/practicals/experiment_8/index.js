
const express = require('express');
const mongoose = require('mongoose');


mongoose.connect("mongodb://adminuser:admin@localhost:27017/newdb?authSource=admin")

const app = express()

app.use(express.json())

const userSchema = new mongoose.Schema({
    name: {
        type: String,
    },
    email: {
        type: String,
        required: true,
        unique: true,
    },
    age: {
        type: Number,
        min: 0,
        max: 120,
        required: false
    }
}, { timestamp: true });

const User = mongoose.model('User', userSchema)

app.get("/users", (req, res) => {
    User.find().then((users) => {
        res.status(200).send(users)
    }).catch((e) => {
        console.log({ e })
        res.status(400).send({ "error": "failed to get" });
    })
})


app.get("/users/:id", (req, res) => {
    const id = req.params.id
    User.findById(id).then((user) => {
        res.status(200).send(user)
    }).catch((e) => {
        console.log({ e })
        res.status(400).send({ "error": "failed to get" });
    })
})


app.post("/users", (req, res) => {
    const user = new User(req.body);
    user.save().then(() => {
        res.status(201).send(user);
    }).catch((e) => {
        console.log({ e })
        res.status(400).send({ "error": "failed to create" });
    })
})


app.put("/users/:id", (req, res) => {
    const id = req.params.id
    const user = req.body
    User.findByIdAndUpdate(id, user, { new: true, runValidators: true }).then((user) => {
        res.status(200).send(user);
    }).catch((e) => {
        console.log({ e })
        res.status(400).send({ "error": "failed to get" });
    })
})

app.delete("/users/:id", (req, res) => {
    const id = req.params.id
    User.findByIdAndDelete(id).then((user) => {
        res.status(200).send(user);
    }).catch((e) => {
        console.log({ e })
        res.status(400).send({ "error": "failed to get" });
    })
})



app.listen(3000, () => { console.log("server running") })
