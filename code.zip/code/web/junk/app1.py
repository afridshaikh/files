from flask import Flask, url_for, request, make_response


app = Flask("first app")
app.config['UPLOAD_FOLDER'] = "/Users/afridshaikh/Documents/projects/sessions/web/junk/files"



@app.route("/name/<name>")
def name(name):
    return f"<h1> Name is {name}</h1>"

@app.route("/id/<int:id>")
def id(id):
    return f"<h1> Id is {id}</h1>"


@app.route("/details-list", methods=["POST"])
def details_list():
    id = request.form.get("id")
    name = request.form.get("name")
    id_link = url_for("id", id=id)
    name_link = url_for("name", name=name)
    return f"""
        Id Link: <a href={id_link}> id link</a><br>
        Name Link: <a href={name_link}> name link</a>
"""



@app.route("/details-form")
def details_form():
    return """
    <html>
        <form action="/details-list" method="post">
            <input type="text" name="id">
            <input type="text" name="name">
            <button type="submit">submit</button>
        </form>
    </html>
    """





@app.route("/set-theme")
def set_theme():
    r = make_response()
    theme = request.args.get("theme")
    if theme == "dark":
        r.set_cookie("theme", "dark", max_age=5)

    else:
        r.set_cookie("theme", "light", max_age=5)
    return r

@app.route("/dashboard")
def dashboard():
    theme = request.cookies.get("theme",)
    print("theme ", theme)
    if theme == "dark":
        return '''
                <h1 style=\"background-color: black; color: white\"> Hello </h1>
            '''
    return '''<h1> Hello </h1>'''

@app.route('/user/<username>')
def user_profile(username):
    return f"Profile page of {username}"

@app.route('/post/<int:post_id>')
def show_post(post_id):
    # Returns details for a post identified by post_id.
    return f"Post #{post_id}"


@app.route("/form-data", methods=["POST"])
def form_data():
    name = request.form.get("name")
    profile_link = url_for("user_profile", username=name)
    return (f"<a href=\"{profile_link}\"> profile link </a>")



@app.route("/file-upload", methods=["GET", "POST"])
def upload():
    if request.method == "POST":
        files = request.files
        file = files["some_file"]
        file.save(app.config['UPLOAD_FOLDER'] + "/somefile")
        return str(files)
    if request.method == "GET":
        return '''
    <!doctype html>
    <title>Upload File</title>
    <h1>Upload New File</h1>
    <form method="post" enctype="multipart/form-data">
      <input type="file" name="some_file">
      <input type="submit" value="/file-upload">
    </form>
    '''

@app.route('/')
def index():
    user_url = url_for('user_profile', username='alice')
    post_url = url_for('show_post', post_id=42)
    return (
        "<form method=\"POST\" action=\"/form-data\">  <input type=\"text\" name=\"name\"/> <button type=\"submit\"> submit </button>  </form>"
    )



if __name__ == '__main__':
    app.run(debug=True)
