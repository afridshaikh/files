"""
api/stage1_service.py
=====================
Loads stage1_detection.pkl, runs SMA detection prediction.
Binary output: SMA detected (Yes/No) + SMA type + risk score.
"""

import os
import pandas as pd
import joblib

MODEL_PATH = "model/stage1_detection.pkl"

SMA_TYPES = {
    0: ("None",   "No SMA detected"),
    1: ("Type 1", "Severe — onset before 6 months (Werdnig–Hoffmann)"),
    2: ("Type 2", "Intermediate — onset 6–18 months (Dubowitz)"),
    3: ("Type 3", "Mild — onset after 18 months (Kugelberg–Welander)"),
    4: ("Type 4", "Adult-onset SMA"),
}

_bundle = None


def load():
    global _bundle
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(
            "model/stage1_detection.pkl not found.\n"
            "Run: python data/generate_data.py && python model/train.py"
        )
    _bundle = joblib.load(MODEL_PATH)
    print(f"✅  Stage 1 loaded: {_bundle['model_name']}  "
          f"AUC={_bundle['auc']}  Acc={_bundle['accuracy']*100:.1f}%")


def get_info():
    return {k: _bundle[k] for k in ("model_name", "auc", "accuracy")} if _bundle else {}


def predict(data: dict) -> dict:
    row    = pd.DataFrame([data])[_bundle["features"]]
    row_s  = _bundle["scaler"].transform(row)
    proba  = _bundle["model"].predict_proba(row_s)[0]
    score  = float(proba[1])
    pred   = int(score >= 0.50)

    if score < 0.25:   level = "Low"
    elif score < 0.50: level = "Moderate"
    elif score < 0.75: level = "High"
    else:              level = "Very High"

    # Infer SMA type from SMN2 copies
    smn2 = int(data.get("smn2_copies", 2))
    if not pred:       tk = 0
    elif smn2 <= 1:    tk = 1
    elif smn2 == 2:    tk = 2
    elif smn2 == 3:    tk = 3
    else:              tk = 4

    # Key factors driving the result
    factors = []
    if data.get("smn1_copies", 2) == 0:
        factors.append("SMN1 homozygous deletion (0 copies) — primary SMA cause")
    elif data.get("smn1_copies", 2) == 1:
        factors.append("SMN1 heterozygous (1 copy) — elevated risk")
    if data.get("eim_signal", 55) < 40:
        factors.append(f"Reduced EIM signal ({data['eim_signal']} µS, normal 50–60)")
    if data.get("motor_score", 88) < 65:
        factors.append(f"Impaired motor function ({data['motor_score']}/100)")
    if data.get("weakness_score", 1) > 5:
        factors.append(f"Significant muscle weakness ({data['weakness_score']}/10)")
    if data.get("family_history", 0) == 1:
        factors.append("Positive family history of SMA")
    if data.get("fvc_percent", 95) < 70:
        factors.append(f"Respiratory compromise (FVC {data['fvc_percent']}%)")
    if data.get("ck_level", 100) > 200:
        factors.append(f"Elevated CK level ({data['ck_level']} U/L)")
    if not factors:
        factors.append("No dominant single risk factor identified")

    return {
        "risk_score":    round(score, 4),
        "risk_percent":  round(score * 100, 1),
        "risk_level":    level,
        "sma_detected":  bool(pred),
        "sma_type":      SMA_TYPES[tk][0],
        "sma_type_desc": SMA_TYPES[tk][1],
        "sma_type_num":  tk,
        "confidence":    round(float(max(proba)) * 100, 1),
        "key_factors":   factors,
    }
