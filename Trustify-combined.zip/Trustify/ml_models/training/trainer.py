# ml_models/training/trainer.py
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from typing import Dict, List, Tuple, Optional
import numpy as np
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import logging
from tqdm import tqdm
import wandb  # For experiment tracking

logger = logging.getLogger(__name__)

class TrustifyTrainer:
    """Complete training pipeline for Trustify model"""
    
    def __init__(self,
                 model: nn.Module,
                 device: torch.device,
                 experiment_name: str = "trustify_experiment",
                 use_wandb: bool = True):
        
        self.model = model.to(device)
        self.device = device
        self.experiment_name = experiment_name
        self.use_wandb = use_wandb
        
        # Initialize experiment tracking
        if use_wandb:
            wandb.init(project="trustify-fake-review-detection", name=experiment_name)
    
    def train(self,
              train_loader: DataLoader,
              val_loader: DataLoader,
              test_loader: Optional[DataLoader],
              num_epochs: int = 50,
              learning_rate: float = 0.001,
              weight_decay: float = 1e-4,
              patience: int = 10,
              checkpoint_dir: str = "./checkpoints") -> Dict[str, List[float]]:
        """
        Complete training procedure
        
        Returns:
            Dictionary containing training history
        """
        # Initialize optimizer
        optimizer = torch.optim.AdamW(
            self.model.parameters(),
            lr=learning_rate,
            weight_decay=weight_decay
        )
        
        # Learning rate scheduler
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer,
            mode='min',
            factor=0.5,
            patience=5,
            verbose=True
        )
        
        # Early stopping
        best_val_loss = float('inf')
        epochs_no_improve = 0
        best_model_state = None
        
        # Training history
        history = {
            'train_loss': [],
            'val_loss': [],
            'train_acc': [],
            'val_acc': [],
            'train_f1': [],
            'val_f1': []
        }
        
        # Adversarial training parameters
        adversarial_epochs = [10, 20, 30]  # Apply adversarial training at these epochs
        
        for epoch in range(num_epochs):
            logger.info(f"\nEpoch {epoch+1}/{num_epochs}")
            
            # Training phase
            train_metrics = self._train_epoch(
                train_loader, optimizer, 
                use_adversarial=(epoch in adversarial_epochs)
            )
            
            # Validation phase
            val_metrics = self._validate_epoch(val_loader)
            
            # Update learning rate
            scheduler.step(val_metrics['loss'])
            
            # Log metrics
            history['train_loss'].append(train_metrics['loss'])
            history['val_loss'].append(val_metrics['loss'])
            history['train_acc'].append(train_metrics['accuracy'])
            history['val_acc'].append(val_metrics['accuracy'])
            history['train_f1'].append(train_metrics['f1_score'])
            history['val_f1'].append(val_metrics['f1_score'])
            
            # Log to wandb
            if self.use_wandb:
                wandb.log({
                    'epoch': epoch,
                    'train_loss': train_metrics['loss'],
                    'val_loss': val_metrics['loss'],
                    'train_accuracy': train_metrics['accuracy'],
                    'val_accuracy': val_metrics['accuracy'],
                    'train_f1': train_metrics['f1_score'],
                    'val_f1': val_metrics['f1_score'],
                    'learning_rate': optimizer.param_groups[0]['lr']
                })
            
            # Print epoch summary
            logger.info(f"Train Loss: {train_metrics['loss']:.4f}, "
                       f"Train Acc: {train_metrics['accuracy']:.4f}, "
                       f"Train F1: {train_metrics['f1_score']:.4f}")
            logger.info(f"Val Loss: {val_metrics['loss']:.4f}, "
                       f"Val Acc: {val_metrics['accuracy']:.4f}, "
                       f"Val F1: {val_metrics['f1_score']:.4f}")
            
            # Check for improvement
            if val_metrics['loss'] < best_val_loss:
                best_val_loss = val_metrics['loss']
                epochs_no_improve = 0
                
                # Save best model
                best_model_state = {
                    'epoch': epoch,
                    'model_state_dict': self.model.state_dict(),
                    'optimizer_state_dict': optimizer.state_dict(),
                    'val_loss': best_val_loss,
                    'val_accuracy': val_metrics['accuracy']
                }
                
                torch.save(
                    best_model_state,
                    f"{checkpoint_dir}/best_model_epoch_{epoch}.pt"
                )
                logger.info(f"Saved best model with val_loss: {best_val_loss:.4f}")
            else:
                epochs_no_improve += 1
            
            # Early stopping
            if epochs_no_improve >= patience:
                logger.info(f"Early stopping triggered at epoch {epoch}")
                break
        
        # Load best model
        if best_model_state:
            self.model.load_state_dict(best_model_state['model_state_dict'])
            logger.info(f"Loaded best model from epoch {best_model_state['epoch']}")
        
        # Final evaluation on test set
        if test_loader:
            test_metrics = self._validate_epoch(test_loader)
            logger.info(f"\nTest Results: "
                       f"Loss: {test_metrics['loss']:.4f}, "
                       f"Accuracy: {test_metrics['accuracy']:.4f}, "
                       f"F1: {test_metrics['f1_score']:.4f}")
            
            if self.use_wandb:
                wandb.log({
                    'test_loss': test_metrics['loss'],
                    'test_accuracy': test_metrics['accuracy'],
                    'test_f1': test_metrics['f1_score']
                })
        
        # Save final model
        final_checkpoint = {
            'epoch': num_epochs,
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            'history': history
        }
        torch.save(final_checkpoint, f"{checkpoint_dir}/final_model.pt")
        
        # Close wandb
        if self.use_wandb:
            wandb.finish()
        
        return history
    
    def _train_epoch(self, 
                     dataloader: DataLoader, 
                     optimizer: torch.optim.Optimizer,
                     use_adversarial: bool = False) -> Dict[str, float]:
        """Train for one epoch"""
        self.model.train()
        total_loss = 0
        all_predictions = []
        all_labels = []
        
        pbar = tqdm(dataloader, desc="Training", leave=False)
        
        for batch_idx, batch in enumerate(pbar):
            # Move to device
            batch = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v 
                    for k, v in batch.items()}
            
            # Forward pass
            optimizer.zero_grad()
            logits, _ = self.model(
                batch['text_indices'],
                batch['behavioral_features'],
                batch['contextual_features']
            )
            
            # Calculate loss with class weighting
            loss = self._calculate_loss(
                logits, batch['labels'], 
                use_adversarial=use_adversarial
            )
            
            # Backward pass
            loss.backward()
            
            # Gradient clipping
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
            
            # Optimizer step
            optimizer.step()
            
            # Calculate predictions
            predictions = torch.argmax(logits, dim=1)
            
            # Accumulate metrics
            total_loss += loss.item()
            all_predictions.extend(predictions.cpu().numpy())
            all_labels.extend(batch['labels'].cpu().numpy())
            
            # Update progress bar
            pbar.set_postfix({'loss': loss.item()})
        
        # Calculate epoch metrics
        avg_loss = total_loss / len(dataloader)
        accuracy = accuracy_score(all_labels, all_predictions)
        f1 = f1_score(all_labels, all_predictions, average='weighted')
        
        return {
            'loss': avg_loss,
            'accuracy': accuracy,
            'f1_score': f1
        }
    
    def _calculate_loss(self, 
                       logits: torch.Tensor, 
                       labels: torch.Tensor,
                       use_adversarial: bool = False) -> torch.Tensor:
        """Calculate loss with optional adversarial components"""
        # Basic cross-entropy loss
        ce_loss = F.cross_entropy(logits, labels)
        
        # Class weighting for imbalance
        class_weights = torch.tensor([1.0, 2.5], device=logits.device)  # Weight fake class more
        weighted_loss = F.cross_entropy(logits, labels, weight=class_weights)
        
        # Combine losses
        total_loss = weighted_loss
        
        if use_adversarial:
            # Add adversarial loss component
            adv_loss = self._adversarial_loss(logits, labels)
            total_loss += 0.1 * adv_loss
        
        # Add L2 regularization
        l2_lambda = 0.001
        l2_reg = sum(p.pow(2.0).sum() for p in self.model.parameters())
        total_loss += l2_lambda * l2_reg
        
        return total_loss
    
    def _adversarial_loss(self, logits: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
        """Calculate adversarial loss for robustness"""
        # Generate adversarial examples (simplified FGSM)
        logits.requires_grad = True
        
        # Calculate gradient w.r.t. logits
        loss = F.cross_entropy(logits, labels)
        loss.backward(retain_graph=True)
        
        # Create adversarial perturbation
        epsilon = 0.01
        perturbation = epsilon * torch.sign(logits.grad)
        
        # Adversarial loss
        adv_logits = logits + perturbation
        adv_loss = F.cross_entropy(adv_logits, labels)
        
        return adv_loss
    
    def _validate_epoch(self, dataloader: DataLoader) -> Dict[str, float]:
        """Validate for one epoch"""
        self.model.eval()
        total_loss = 0
        all_predictions = []
        all_labels = []
        
        with torch.no_grad():
            pbar = tqdm(dataloader, desc="Validation", leave=False)
            
            for batch in pbar:
                # Move to device
                batch = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v 
                        for k, v in batch.items()}
                
                # Forward pass
                logits, _ = self.model(
                    batch['text_indices'],
                    batch['behavioral_features'],
                    batch['contextual_features']
                )
                
                # Calculate loss
                loss = F.cross_entropy(logits, batch['labels'])
                
                # Calculate predictions
                predictions = torch.argmax(logits, dim=1)
                
                # Accumulate metrics
                total_loss += loss.item()
                all_predictions.extend(predictions.cpu().numpy())
                all_labels.extend(batch['labels'].cpu().numpy())
        
        # Calculate metrics
        avg_loss = total_loss / len(dataloader)
        accuracy = accuracy_score(all_labels, all_predictions)
        precision = precision_score(all_labels, all_predictions, average='weighted')
        recall = recall_score(all_labels, all_predictions, average='weighted')
        f1 = f1_score(all_labels, all_predictions, average='weighted')
        
        return {
            'loss': avg_loss,
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1_score': f1
        }
    
    def evaluate(self, dataloader: DataLoader) -> Dict[str, float]:
        """Comprehensive evaluation"""
        self.model.eval()
        
        all_predictions = []
        all_labels = []
        all_probabilities = []
        
        with torch.no_grad():
            for batch in tqdm(dataloader, desc="Evaluation"):
                # Move to device
                batch = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v 
                        for k, v in batch.items()}
                
                # Forward pass
                logits, _ = self.model(
                    batch['text_indices'],
                    batch['behavioral_features'],
                    batch['contextual_features']
                )
                
                # Calculate predictions and probabilities
                probabilities = F.softmax(logits, dim=1)
                predictions = torch.argmax(logits, dim=1)
                
                all_predictions.extend(predictions.cpu().numpy())
                all_labels.extend(batch['labels'].cpu().numpy())
                all_probabilities.extend(probabilities.cpu().numpy())
        
        # Calculate comprehensive metrics
        from sklearn.metrics import (confusion_matrix, roc_auc_score, 
                                   precision_recall_curve, average_precision_score)
        
        metrics = {}
        
        # Basic classification metrics
        metrics['accuracy'] = accuracy_score(all_labels, all_predictions)
        metrics['precision'] = precision_score(all_labels, all_predictions)
        metrics['recall'] = recall_score(all_labels, all_predictions)
        metrics['f1_score'] = f1_score(all_labels, all_predictions)
        
        # ROC and AUC
        try:
            all_probabilities = np.array(all_probabilities)
            metrics['roc_auc'] = roc_auc_score(all_labels, all_probabilities[:, 1])
            metrics['average_precision'] = average_precision_score(all_labels, all_probabilities[:, 1])
        except:
            metrics['roc_auc'] = 0.0
            metrics['average_precision'] = 0.0
        
        # Confusion matrix
        cm = confusion_matrix(all_labels, all_predictions)
        metrics['confusion_matrix'] = cm
        
        # Additional metrics
        tn, fp, fn, tp = cm.ravel()
        metrics['true_negative_rate'] = tn / (tn + fp) if (tn + fp) > 0 else 0
        metrics['false_positive_rate'] = fp / (fp + tn) if (fp + tn) > 0 else 0
        metrics['false_negative_rate'] = fn / (fn + tp) if (fn + tp) > 0 else 0
        
        # Calculate MCC (Matthews Correlation Coefficient)
        mcc_numerator = (tp * tn) - (fp * fn)
        mcc_denominator = np.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
        metrics['mcc'] = mcc_numerator / mcc_denominator if mcc_denominator > 0 else 0
        
        return metrics