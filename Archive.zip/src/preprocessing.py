from __future__ import annotations
import numpy as np
import pandas as pd

def clean_sensor_data(df: pd.DataFrame) -> pd.DataFrame:
    x = df.copy().sort_values(['node_id','timestamp'])
    bounds = {
        'chlorine_mg_l': (0, 2.5), 'ph': (6.5, 8.5), 'turbidity_ntu': (0, 5),
        'temperature_c': (0, 40), 'flow_lps': (0, 100), 'pressure_bar': (0, 15)
    }
    for col, (lo, hi) in bounds.items():
        if col in x:
            x.loc[x[col].notna() & ((x[col] < lo) | (x[col] > hi)), col] = np.nan
    # IQR outlier handling by sensor variable.
    for col in ['chlorine_mg_l','ph','turbidity_ntu','temperature_c','flow_lps','pressure_bar']:
        if col not in x: continue
        vals = x[col].dropna()
        if len(vals) < 20: continue
        q1, q3 = vals.quantile([.25,.75]); iqr=q3-q1
        lo, hi = q1-3*iqr, q3+3*iqr
        x.loc[(x[col] < lo) | (x[col] > hi), col] = np.nan
    # Time interpolation within each node, followed by median fallback.
    for col in ['chlorine_mg_l','ph','turbidity_ntu','temperature_c','flow_lps','pressure_bar']:
        if col in x:
            x[col] = x.groupby('node_id')[col].transform(lambda s: s.interpolate(limit=8).ffill().bfill())
            x[col] = x[col].fillna(x[col].median())
    return x
