// Primitive types
let id: number = 101;
let uName: string = "John";
let isStudent: boolean = true;

// Array
let hobbies: string[] = ["Reading", "Gaming", "Traveling"];

// Tuple
let userInfo: [number, string] = [1, "Admin"];

// Enum
enum Direction {
    Up,
    Down,
    Left,
    Right
}
let move: Direction = Direction.Up;

// Any
let randomValue: any = "Hello";
randomValue = 100;

// Union Type
let code: string | number;
code = 123;
code = "ABC123";

// Null and Undefined
let nothing: null = null;
let notAssigned: undefined = undefined;

console.log("ID:", id);
console.log("Name:", uName);
console.log("Is Student:", isStudent);
console.log("Hobbies:", hobbies);
console.log("User Info Tuple:", userInfo);
console.log("Direction Enum:", move);
console.log("Random Value:", randomValue);
console.log("Code (Union):", code);
console.log("Null:", nothing);
console.log("Undefined:", notAssigned);
