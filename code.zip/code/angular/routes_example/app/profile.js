const profile = angular.module("profile", [])

profile.controller("Profile", ["$scope", function($scope){
    $scope.profileDetails = "profile details!"
}])