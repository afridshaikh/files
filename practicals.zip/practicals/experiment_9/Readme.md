Aim: Create First Hello world app and URL building in Flask

Objective:
- To set up a Flask web app and define URL routes.



Theory:
- What is Flask and how does routing work?
- How are views mapped to URLs in Flask?


Code:



Conclusion: 


---------------------------------
Instructions to run code:

- Make sure Python is installed.

- Install Flask (if not installed): `pip install flask`

- Save code in a file named `app.py`.

- Run the app using: `python app.py`

- Open browser and visit:

`http://127.0.0.1:5000/`

`http://127.0.0.1:5000/user/YourName`

