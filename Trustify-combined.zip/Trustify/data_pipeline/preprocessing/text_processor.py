# data_pipeline/preprocessing/text_processor.py
import re
import spacy
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import sent_tokenize, word_tokenize
import textstat
from typing import List, Dict, Tuple
import numpy as np
from dataclasses import dataclass
import logging

# Download required NLTK data
nltk.download('punkt', quiet=True)
nltk.download('stopwords', quiet=True)
nltk.download('wordnet', quiet=True)

logger = logging.getLogger(__name__)

@dataclass
class ProcessedText:
    tokens: List[str]
    sentences: List[str]
    pos_tags: List[Tuple[str, str]]
    entities: List[Tuple[str, str]]
    linguistic_features: Dict[str, float]
    cleaned_text: str

class AdvancedTextProcessor:
    """Comprehensive text preprocessing with linguistic analysis"""
    
    def __init__(self, spacy_model: str = 'en_core_web_lg'):
        try:
            self.nlp = spacy.load(spacy_model)
        except OSError:
            logger.warning(f"{spacy_model} not found. Downloading...")
            import subprocess
            subprocess.run(['python', '-m', 'spacy', 'download', spacy_model])
            self.nlp = spacy.load(spacy_model)
        
        self.stop_words = set(stopwords.words('english'))
        self.lemmatizer = WordNetLemmatizer()
        self.special_chars = re.compile(r'[^\w\s.,!?;:\'\"-]')
        
    def process(self, text: str) -> ProcessedText:
        """Main processing pipeline"""
        if not text or not isinstance(text, str):
            return self._create_empty_result()
        
        try:
            # Clean text
            cleaned_text = self._clean_text(text)
            
            # SpaCy processing
            doc = self.nlp(cleaned_text)
            
            # Extract components
            tokens = self._extract_tokens(doc)
            sentences = self._extract_sentences(doc)
            pos_tags = self._extract_pos_tags(doc)
            entities = self._extract_entities(doc)
            
            # Calculate linguistic features
            linguistic_features = self._calculate_linguistic_features(
                cleaned_text, tokens, sentences, doc
            )
            
            return ProcessedText(
                tokens=tokens,
                sentences=sentences,
                pos_tags=pos_tags,
                entities=entities,
                linguistic_features=linguistic_features,
                cleaned_text=cleaned_text
            )
            
        except Exception as e:
            logger.error(f"Error processing text: {e}")
            return self._create_empty_result()
    
    def _clean_text(self, text: str) -> str:
        """Clean and normalize text"""
        # Remove HTML tags
        text = re.sub(r'<[^>]+>', '', text)
        
        # Remove URLs
        text = re.sub(r'https?://\S+|www\.\S+', '', text)
        
        # Remove special characters but preserve punctuation for sentiment
        text = self.special_chars.sub(' ', text)
        
        # Normalize whitespace
        text = re.sub(r'\s+', ' ', text).strip()
        
        # Normalize quotes and apostrophes
        text = text.replace('"', "'").replace('"', "'")
        
        return text
    
    def _extract_tokens(self, doc) -> List[str]:
        """Extract lemmatized tokens"""
        tokens = []
        for token in doc:
            if not token.is_punct and not token.is_space:
                lemma = token.lemma_.lower()
                if (lemma not in self.stop_words and 
                    len(lemma) > 1 and 
                    not lemma.isnumeric()):
                    tokens.append(lemma)
        return tokens
    
    def _extract_sentences(self, doc) -> List[str]:
        """Extract sentences"""
        return [sent.text for sent in doc.sents]
    
    def _extract_pos_tags(self, doc) -> List[Tuple[str, str]]:
        """Extract part-of-speech tags"""
        return [(token.text, token.pos_) for token in doc]
    
    def _extract_entities(self, doc) -> List[Tuple[str, str]]:
        """Extract named entities"""
        return [(ent.text, ent.label_) for ent in doc.ents]
    
    def _calculate_linguistic_features(self, 
                                      text: str, 
                                      tokens: List[str],
                                      sentences: List[str],
                                      doc) -> Dict[str, float]:
        """Calculate comprehensive linguistic features"""
        features = {}
        
        # Basic statistics
        features['num_chars'] = len(text)
        features['num_words'] = len(tokens)
        features['num_sentences'] = len(sentences)
        
        # Sentence statistics
        if sentences:
            sent_lengths = [len(sent.split()) for sent in sentences]
            features['avg_sentence_length'] = np.mean(sent_lengths)
            features['std_sentence_length'] = np.std(sent_lengths)
            features['max_sentence_length'] = np.max(sent_lengths)
        
        # Readability metrics
        features['flesch_reading_ease'] = textstat.flesch_reading_ease(text)
        features['flesch_kincaid_grade'] = textstat.flesch_kincaid_grade(text)
        features['gunning_fog'] = textstat.gunning_fog(text)
        
        # Lexical richness
        if tokens:
            unique_tokens = set(tokens)
            features['type_token_ratio'] = len(unique_tokens) / len(tokens)
            features['hapax_legomena'] = self._count_hapax_legomena(tokens)
        
        # Part-of-speech ratios
        pos_counts = {}
        for token in doc:
            if token.pos_ not in pos_counts:
                pos_counts[token.pos_] = 0
            pos_counts[token.pos_] += 1
        
        total_tokens = sum(pos_counts.values())
        if total_tokens > 0:
            for pos, count in pos_counts.items():
                features[f'pos_ratio_{pos}'] = count / total_tokens
        
        # Punctuation analysis
        punctuation_patterns = [',', '.', '!', '?', ';', ':']
        for punct in punctuation_patterns:
            features[f'punctuation_{punct}'] = text.count(punct) / len(text) if text else 0
        
        return features
    
    def _count_hapax_legomena(self, tokens: List[str]) -> int:
        """Count words that appear only once"""
        from collections import Counter
        counts = Counter(tokens)
        return sum(1 for count in counts.values() if count == 1)
    
    def _create_empty_result(self) -> ProcessedText:
        """Create empty result for error cases"""
        return ProcessedText(
            tokens=[],
            sentences=[],
            pos_tags=[],
            entities=[],
            linguistic_features={},
            cleaned_text=""
        )

# data_pipeline/preprocessing/feature_extractor.py
import pandas as pd
import numpy as np
from typing import List, Dict, Any
from datetime import datetime
from scipy import stats
import json

class FeatureExtractor:
    """Extract features from processed reviews"""
    
    def __init__(self):
        self.text_processor = AdvancedTextProcessor()
    
    def extract_features(self, review_data: Dict[str, Any]) -> Dict[str, Any]:
        """Extract all features from review data"""
        features = {}
        
        # Text features
        if 'review_text' in review_data:
            processed_text = self.text_processor.process(review_data['review_text'])
            features.update(self._extract_text_features(processed_text))
        
        # Metadata features
        features.update(self._extract_metadata_features(review_data))
        
        # Behavioral features (if reviewer history available)
        if 'reviewer_history' in review_data:
            features.update(self._extract_behavioral_features(
                review_data['reviewer_history']
            ))
        
        # Contextual features
        features.update(self._extract_contextual_features(review_data))
        
        return features
    
    def _extract_text_features(self, processed_text) -> Dict[str, Any]:
        """Extract text-based features"""
        features = {}
        
        # Linguistic features from processor
        features.update(processed_text.linguistic_features)
        
        # Additional text features
        features['text_has_links'] = 1 if 'http' in processed_text.cleaned_text.lower() else 0
        features['text_has_emojis'] = self._count_emojis(processed_text.cleaned_text)
        
        # Sentiment features (simplified - would integrate with proper sentiment analysis)
        features['text_exclamation_count'] = processed_text.cleaned_text.count('!')
        features['text_caps_ratio'] = self._calculate_caps_ratio(processed_text.cleaned_text)
        
        return features
    
    def _extract_metadata_features(self, review_data: Dict[str, Any]) -> Dict[str, Any]:
        """Extract metadata-based features"""
        features = {}
        
        # Rating features
        rating = review_data.get('rating', 0)
        features['rating'] = rating
        features['rating_extreme'] = 1 if rating in [1, 5] else 0
        features['rating_deviation'] = abs(rating - review_data.get('product_avg_rating', 3))
        
        # Temporal features
        review_date = review_data.get('review_date')
        if review_date:
            if isinstance(review_date, str):
                review_date = datetime.fromisoformat(review_date.replace('Z', '+00:00'))
            
            features['review_hour'] = review_date.hour
            features['review_day_of_week'] = review_date.weekday()
            features['review_month'] = review_date.month
            
            # Time since product launch (if available)
            launch_date = review_data.get('product_launch_date')
            if launch_date:
                if isinstance(launch_date, str):
                    launch_date = datetime.fromisoformat(launch_date.replace('Z', '+00:00'))
                features['days_since_launch'] = (review_date - launch_date).days
        
        # Reviewer features
        features['reviewer_total_reviews'] = review_data.get('reviewer_total_reviews', 0)
        features['reviewer_helpfulness_ratio'] = self._calculate_helpfulness_ratio(review_data)
        features['verified_purchase'] = 1 if review_data.get('verified_purchase', False) else 0
        
        return features
    
    def _extract_behavioral_features(self, reviewer_history: List[Dict]) -> Dict[str, Any]:
        """Extract behavioral patterns from reviewer history"""
        if not reviewer_history or len(reviewer_history) < 2:
            return {}
        
        features = {}
        
        # Convert to DataFrame for analysis
        df = pd.DataFrame(reviewer_history)
        
        # Temporal patterns
        if 'review_date' in df.columns:
            df['review_date'] = pd.to_datetime(df['review_date'])
            df = df.sort_values('review_date')
            
            # Time between reviews
            time_diffs = df['review_date'].diff().dt.total_seconds()
            features['avg_time_between_reviews'] = time_diffs.mean() if len(time_diffs) > 1 else 0
            features['std_time_between_reviews'] = time_diffs.std() if len(time_diffs) > 1 else 0
            
            # Reviewing frequency
            total_days = (df['review_date'].max() - df['review_date'].min()).days
            features['reviews_per_day'] = len(df) / max(total_days, 1)
        
        # Rating patterns
        if 'rating' in df.columns:
            features['reviewer_avg_rating'] = df['rating'].mean()
            features['reviewer_rating_std'] = df['rating'].std()
            features['reviewer_rating_skew'] = stats.skew(df['rating']) if len(df) > 2 else 0
            
            # Rating distribution
            rating_counts = df['rating'].value_counts()
            for i in range(1, 6):
                features[f'reviewer_rating_{i}_count'] = rating_counts.get(i, 0)
        
        # Content patterns (if text available)
        if 'review_text' in df.columns:
            # Simple content similarity analysis
            text_lengths = df['review_text'].str.len()
            features['avg_text_length'] = text_lengths.mean()
            features['text_length_variation'] = text_lengths.std()
        
        return features
    
    def _extract_contextual_features(self, review_data: Dict[str, Any]) -> Dict[str, Any]:
        """Extract contextual features"""
        features = {}
        
        # Product context
        features['product_price_percentile'] = review_data.get('product_price_percentile', 0.5)
        features['product_review_count'] = review_data.get('product_total_reviews', 0)
        features['product_avg_rating'] = review_data.get('product_avg_rating', 3.0)
        
        # Platform context
        platform = review_data.get('platform', '').lower()
        features[f'platform_{platform}'] = 1
        
        # Market context
        features['category_competition_score'] = review_data.get('category_competition', 0.5)
        
        return features
    
    def _calculate_helpfulness_ratio(self, review_data: Dict[str, Any]) -> float:
        """Calculate helpfulness ratio"""
        helpful = review_data.get('helpful_votes', 0)
        total = review_data.get('total_votes', 0)
        
        if total > 0:
            return helpful / total
        return 0.0
    
    def _count_emojis(self, text: str) -> int:
        """Count emojis in text (simplified)"""
        # Basic emoji detection - would use proper emoji library in production
        emoji_pattern = re.compile(
            "["
            "\U0001F600-\U0001F64F"  # emoticons
            "\U0001F300-\U0001F5FF"  # symbols & pictographs
            "\U0001F680-\U0001F6FF"  # transport & map symbols
            "\U0001F1E0-\U0001F1FF"  # flags (iOS)
            "]+",
            flags=re.UNICODE
        )
        return len(emoji_pattern.findall(text))
    
    def _calculate_caps_ratio(self, text: str) -> float:
        """Calculate ratio of uppercase letters"""
        if not text:
            return 0.0
        
        letters = [c for c in text if c.isalpha()]
        if not letters:
            return 0.0
        
        uppercase = [c for c in letters if c.isupper()]
        return len(uppercase) / len(letters)