# Suggested experiment notebook sequence

1. Load `data/synthetic_scada_clean.csv`.
2. Plot chlorine by distance/node and demand period.
3. Compare physics-only prediction with PINN.
4. Evaluate chronological 70/15/15 split.
5. Inject additional booster failures and measure detection time.
6. Compare optimization under different compliance thresholds.
7. Add an XGBoost baseline and compare against the PINN.
8. Replace the synthetic graph with an EPANET/WNTR `.inp` network.
