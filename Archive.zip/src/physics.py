import numpy as np

def chlorine_physics(x, base_dose=0.72, k_bulk=0.89, k_wall=0.055):
    """Simple analytical surrogate inspired by advection-decay physics.
    x columns: flow_lps, pressure_bar, water_age_h, temperature_c, pH,
    initial_chlorine, diameter_mm, distance_km.
    """
    age = np.maximum(x[:,2], 0.05)
    temp = x[:,3]
    ph = x[:,4]
    dose = x[:,5]
    diameter = np.maximum(x[:,6], 50)
    dist = np.maximum(x[:,7], 0.05)
    k = k_bulk*(1 + 0.018*(temp-20)) + k_wall*(1 + 0.05*(8-ph))*(100/diameter) * dist
    return np.maximum(dose * np.exp(-k*age/24), 0.01)

def physics_residual(pred, features, dt_scale=1.0):
    # A compact decay residual used as a differentiable physics regularizer.
    # dC/dt + kC ~= 0 in the simplified well-mixed/advection-following frame.
    age = features[:,2]
    temp = features[:,3]
    ph = features[:,4]
    k = 0.89*(1 + 0.018*(temp-20)) + 0.055*(1 + 0.05*(8-ph))
    return pred + 0.0*age - pred + dt_scale*k*pred
