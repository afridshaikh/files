# SMA Clinical Decision System
ME IT · University of Mumbai · Smit Mahesh Wani (Roll No. 14)
Guide: Dr. Namdeo Badhe

---

## What it does

**Stage 1 — SMA Detection**
Takes 11 clinical features → RF+XGBoost ensemble → binary prediction (SMA Yes/No) + SMA type + risk score

**Stage 2 — Progression Assessment**
Only unlocks if Stage 1 detects SMA. Takes additional progression features → separate trained model → severity (Mild / Moderate / Severe) + probability distribution + clinical drivers

---

## Project Structure

```
sma-final/
├── data/
│   ├── generate_data.py      # Generates both datasets
│   ├── sma_detection.csv     # Stage 1 training data (auto-created)
│   └── sma_progression.csv   # Stage 2 training data (auto-created)
├── model/
│   ├── train.py              # Trains both models
│   ├── stage1_detection.pkl  # Stage 1 model (auto-created)
│   └── stage2_progression.pkl # Stage 2 model (auto-created)
├── api/
│   ├── __init__.py
│   ├── main.py               # FastAPI — /detect and /progression
│   ├── stage1_service.py     # Stage 1 inference
│   └── stage2_service.py     # Stage 2 inference
├── ui/
│   └── index.html            # Two-stage UI, Stage 2 locked until SMA confirmed
├── requirements.txt
└── README.md
```

---

## Run order

```bash
# 1. Install
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt

# 2. Generate both datasets
python data/generate_data.py
#   → data/sma_detection.csv   (5,000 records)
#   → data/sma_progression.csv (3,000 SMA patients)

# 3. Train both models
python model/train.py
#   → model/stage1_detection.pkl
#   → model/stage2_progression.pkl
#   Prints accuracy, AUC, F1 for both

# 4. Run
uvicorn api.main:app --reload
# Open: http://localhost:8000
```

---

## Stage 1 Features (Detection)

| Feature | Description |
|---------|-------------|
| age, gender | Demographics |
| smn1_copies | SMN1 gene copies — 0 = deletion = primary SMA cause |
| smn2_copies | SMN2 copies — determines disease type |
| eim_signal | EIM µS — <40 indicates muscle pathology |
| ck_level | CK U/L — elevated in muscle disease |
| motor_score | 0–100 motor function |
| weakness_score | 0–10 weakness severity |
| onset_age | Symptom onset age |
| family_history | 0/1 |
| fvc_percent | Respiratory function % |

**Label:** sma_positive (0/1)

---

## Stage 2 Features (Progression)

| Feature | Description |
|---------|-------------|
| sma_type | 1–4 (from Stage 1) |
| smn2_copies | Disease modifier |
| age_at_diagnosis | Age when SMA was confirmed |
| time_since_diagnosis | Months since diagnosis |
| treatment_status | 0=none, 1=on DMT |
| motor_score | Current motor function |
| motor_trend | Motor score change per 6 months |
| fvc_percent | Current FVC % |
| fvc_trend | FVC change per 6 months |
| weakness_score | Current weakness |
| bulbar_score | Swallowing/speech function 0–10 |

**Label:** severity (0=Mild, 1=Moderate, 2=Severe)

---

## API

| Method | Route | Description |
|--------|-------|-------------|
| GET | `/` | UI |
| GET | `/health` | Both model statuses |
| POST | `/detect` | Stage 1 — SMA detection |
| POST | `/progression` | Stage 2 — Progression severity |
