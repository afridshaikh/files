const junk = angular.module("junk", [])

junk.controller("Junk", ['$scope', function($scope) {
    $scope.todoList = ["task1", "task1"]

    $scope.remove = function(index) {
        $scope.todoList.splice(index,1)
    }

    $scope.addTask = function(){
        $scope.todoList.push($scope.toDoInput);
        $scope.toDoInput = ""
    }

}])