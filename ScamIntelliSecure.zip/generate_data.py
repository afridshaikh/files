import os
from pathlib import Path
import numpy as np
import pandas as pd

n_samples = 100000
np.random.seed(42)

data = []

fraud_rate = 0.50  # realistic fraud ratio: 2%
for i in range(n_samples):
    is_fraud = np.random.choice([0, 1], p=[1 - fraud_rate, fraud_rate])

    # Amount distribution (log-normal for natural spending distribution)
    amount = abs(np.random.lognormal(mean=5 if not is_fraud else 7, sigma=0.7))

    # Time pattern: Fraud tends to happen more late-night
    fraud_probs = np.array([
        0.05, 0.05, 0.05, 0.05, 0.03, 0.03, 0.02, 0.02, 0.04, 0.05, 0.05, 0.05,
        0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.06, 0.08, 0.10, 0.06, 0.06
    ])

    fraud_probs /= fraud_probs.sum()  # normalize to sum == 1.0

    time_hour = np.random.choice(
        range(24),
        p=fraud_probs if is_fraud else [1 / 24] * 24
    )

    # Location mismatch — can happen sometimes even in legit spending
    location_mismatch = np.random.choice([0, 1], p=[0.95, 0.05] if not is_fraud else [0.4, 0.6])

    # Merchant risk — overlap ranges instead of clean cut
    merchant_risk = np.clip(np.random.normal(0.15 if not is_fraud else 0.6, 0.2), 0, 1)

    # Transaction frequency — overlap distributions
    transaction_frequency = np.random.poisson(2 if not is_fraud else 6)

    # Amount deviation from user's mean — imperfect signal
    amount_deviation = abs(np.random.normal(0.1 if not is_fraud else 1.0, 0.4))

    # Add noise — real data is messy
    noise = np.random.normal(0, 0.05)
    amount += noise * amount

    data.append({
        'transaction_id': i + 1,
        'amount': round(amount, 2),
        'time_hour': time_hour,
        'location_mismatch': location_mismatch,
        'merchant_risk': round(float(merchant_risk), 3),
        'transaction_frequency': transaction_frequency,
        'amount_deviation': round(float(amount_deviation), 3),
        'is_fraud': is_fraud
    })

df = pd.DataFrame(data)
path = Path(os.path.join(os.getcwd(), 'data'))
path.mkdir(parents=True, exist_ok=True)
df.to_csv(path.__str__() + "/training.csv", index=False)
