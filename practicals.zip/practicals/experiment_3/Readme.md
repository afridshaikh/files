Aim: Implement datatypes in TypeScript.

Objective:
- To learn and use various datatypes available in TypeScript.

Theory:
- What are the different primitive and non-primitive datatypes in TypeScript?
- How does TypeScript enforce type checking?


Code:



Conclusion: 


---------------------------------
Instructions to run code:

- Save the code in a file named `datatypes.ts`.

- Compile the TypeScript file: `tsc datatypes.ts`

- Run the output JavaScript file: `node datatypes.js`