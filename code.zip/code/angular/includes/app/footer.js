const footer = angular.module("footer", [])

footer.controller("Footer", ["$scope", function($scope){
    $scope.footerText = "Footer"
}])