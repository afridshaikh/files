# ml_models/cnn_apso/model.py
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Tuple, Dict, Optional
import logging

logger = logging.getLogger(__name__)

class CNNTextEncoder(nn.Module):
    """CNN-based text encoder with multiple filter sizes"""
    
    def __init__(self, 
                 vocab_size: int,
                 embedding_dim: int = 128,
                 num_filters: int = 100,
                 filter_sizes: Tuple[int, ...] = (3, 4, 5),
                 dropout_rate: float = 0.5):
        super().__init__()
        
        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=0)
        
        # Multiple convolutional layers with different filter sizes
        self.convs = nn.ModuleList([
            nn.Conv1d(
                in_channels=embedding_dim,
                out_channels=num_filters,
                kernel_size=fs,
                padding=fs // 2  # Same padding
            )
            for fs in filter_sizes
        ])
        
        # Attention mechanism
        self.attention = nn.MultiheadAttention(
            embed_dim=num_filters,
            num_heads=4,
            dropout=0.1,
            batch_first=True
        )
        
        # Layer normalization
        self.layer_norm = nn.LayerNorm(num_filters)
        
        # Dropout
        self.dropout = nn.Dropout(dropout_rate)
        
        # Initialize weights
        self._initialize_weights()
    
    def _initialize_weights(self):
        """Initialize model weights"""
        nn.init.xavier_uniform_(self.embedding.weight)
        for conv in self.convs:
            nn.init.kaiming_normal_(conv.weight, nonlinearity='relu')
            nn.init.constant_(conv.bias, 0)
    
    def forward(self, text_indices: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass through CNN text encoder
        
        Args:
            text_indices: Tensor of shape (batch_size, seq_length)
            
        Returns:
            Tuple of (encoded_features, attention_weights)
        """
        # Embedding layer
        embedded = self.embedding(text_indices)  # (batch_size, seq_length, embedding_dim)
        embedded = self.dropout(embedded)
        
        # Permute for Conv1d: (batch_size, embedding_dim, seq_length)
        embedded = embedded.permute(0, 2, 1)
        
        # Apply convolutional layers
        conved_features = []
        for conv in self.convs:
            conv_out = F.relu(conv(embedded))
            
            # Global max pooling
            pooled = F.max_pool1d(conv_out, conv_out.shape[2])
            conved_features.append(pooled.squeeze(2))
        
        # Concatenate features from different filter sizes
        concatenated = torch.cat(conved_features, dim=1)  # (batch_size, num_filters * len(filter_sizes))
        
        # Reshape for attention: (batch_size, 1, feature_dim)
        concatenated = concatenated.unsqueeze(1)
        
        # Apply self-attention
        attended, attention_weights = self.attention(
            concatenated, concatenated, concatenated
        )
        
        # Layer normalization and dropout
        attended = self.layer_norm(attended)
        attended = self.dropout(attended)
        
        # Squeeze back: (batch_size, feature_dim)
        encoded_features = attended.squeeze(1)
        
        return encoded_features, attention_weights

class BehavioralEncoder(nn.Module):
    """Encoder for behavioral features"""
    
    def __init__(self, 
                 input_dim: int,
                 hidden_dims: Tuple[int, ...] = (64, 32),
                 dropout_rate: float = 0.3):
        super().__init__()
        
        layers = []
        current_dim = input_dim
        
        for hidden_dim in hidden_dims:
            layers.extend([
                nn.Linear(current_dim, hidden_dim),
                nn.BatchNorm1d(hidden_dim),
                nn.ReLU(),
                nn.Dropout(dropout_rate)
            ])
            current_dim = hidden_dim
        
        self.network = nn.Sequential(*layers)
    
    def forward(self, behavioral_features: torch.Tensor) -> torch.Tensor:
        return self.network(behavioral_features)

class ContextualEncoder(nn.Module):
    """Encoder for contextual features"""
    
    def __init__(self, 
                 input_dim: int,
                 hidden_dims: Tuple[int, ...] = (32, 16),
                 dropout_rate: float = 0.2):
        super().__init__()
        
        layers = []
        current_dim = input_dim
        
        for hidden_dim in hidden_dims:
            layers.extend([
                nn.Linear(current_dim, hidden_dim),
                nn.ReLU(),
                nn.Dropout(dropout_rate)
            ])
            current_dim = hidden_dim
        
        self.network = nn.Sequential(*layers)
    
    def forward(self, contextual_features: torch.Tensor) -> torch.Tensor:
        return self.network(contextual_features)

class AdaptiveParticleSwarmOptimizer:
    """Adaptive Particle Swarm Optimization for hyperparameter tuning"""
    
    def __init__(self, 
                 num_particles: int = 30,
                 num_dimensions: int = 10,
                 inertia_range: Tuple[float, float] = (0.4, 0.9),
                 cognitive_range: Tuple[float, float] = (1.5, 2.5),
                 social_range: Tuple[float, float] = (1.5, 2.5)):
        
        self.num_particles = num_particles
        self.num_dimensions = num_dimensions
        
        # Initialize particles with random positions
        self.particles = np.random.uniform(-1, 1, (num_particles, num_dimensions))
        
        # Initialize velocities
        self.velocities = np.zeros((num_particles, num_dimensions))
        
        # Personal best positions and values
        self.personal_best_positions = self.particles.copy()
        self.personal_best_values = np.full(num_particles, np.inf)
        
        # Global best
        self.global_best_position = None
        self.global_best_value = np.inf
        
        # Adaptive parameters
        self.inertia_range = inertia_range
        self.cognitive_range = cognitive_range
        self.social_range = social_range
        
        # Convergence tracking
        self.convergence_history = []
    
    def optimize(self, 
                 objective_function,
                 max_iterations: int = 100,
                 patience: int = 10,
                 tolerance: float = 1e-6) -> np.ndarray:
        """
        Run APSO optimization
        
        Args:
            objective_function: Function to minimize
            max_iterations: Maximum number of iterations
            patience: Early stopping patience
            tolerance: Convergence tolerance
            
        Returns:
            Best found solution
        """
        no_improvement_count = 0
        
        for iteration in range(max_iterations):
            # Adaptive parameter adjustment
            w = self._calculate_adaptive_inertia(iteration, max_iterations)
            c1, c2 = self._calculate_adaptive_coefficients(iteration, max_iterations)
            
            # Evaluate all particles
            current_values = np.array([
                objective_function(particle) for particle in self.particles
            ])
            
            # Update personal bests
            improvement_mask = current_values < self.personal_best_values
            self.personal_best_positions[improvement_mask] = self.particles[improvement_mask]
            self.personal_best_values[improvement_mask] = current_values[improvement_mask]
            
            # Update global best
            current_best_idx = np.argmin(current_values)
            current_best_value = current_values[current_best_idx]
            
            if current_best_value < self.global_best_value:
                improvement = self.global_best_value - current_best_value
                self.global_best_value = current_best_value
                self.global_best_position = self.particles[current_best_idx].copy()
                no_improvement_count = 0
                
                logger.info(f"Iteration {iteration}: New global best: {current_best_value:.6f}")
            else:
                no_improvement_count += 1
            
            # Check convergence
            self.convergence_history.append(self.global_best_value)
            
            if no_improvement_count >= patience:
                logger.info(f"Early stopping at iteration {iteration}")
                break
            
            if iteration > 0:
                improvement_rate = abs(
                    self.convergence_history[-1] - self.convergence_history[-2]
                )
                if improvement_rate < tolerance:
                    logger.info(f"Converged at iteration {iteration}")
                    break
            
            # Update velocities and positions
            self._update_velocities(w, c1, c2)
            self._update_positions()
        
        return self.global_best_position
    
    def _calculate_adaptive_inertia(self, 
                                  iteration: int, 
                                  max_iterations: int) -> float:
        """Calculate adaptive inertia weight"""
        w_min, w_max = self.inertia_range
        return w_max - (w_max - w_min) * (iteration / max_iterations)
    
    def _calculate_adaptive_coefficients(self, 
                                       iteration: int, 
                                       max_iterations: int) -> Tuple[float, float]:
        """Calculate adaptive cognitive and social coefficients"""
        c1_min, c1_max = self.cognitive_range
        c2_min, c2_max = self.social_range
        
        # Linearly decrease c1, increase c2
        progress = iteration / max_iterations
        c1 = c1_max - (c1_max - c1_min) * progress
        c2 = c2_min + (c2_max - c2_min) * progress
        
        return c1, c2
    
    def _update_velocities(self, w: float, c1: float, c2: float):
        """Update particle velocities"""
        r1 = np.random.rand(self.num_particles, self.num_dimensions)
        r2 = np.random.rand(self.num_particles, self.num_dimensions)
        
        cognitive_component = c1 * r1 * (self.personal_best_positions - self.particles)
        social_component = c2 * r2 * (self.global_best_position - self.particles)
        
        self.velocities = (
            w * self.velocities + 
            cognitive_component + 
            social_component
        )
        
        # Velocity clamping to prevent explosion
        velocity_max = 1.0
        self.velocities = np.clip(self.velocities, -velocity_max, velocity_max)
    
    def _update_positions(self):
        """Update particle positions"""
        self.particles += self.velocities
        
        # Boundary handling - reflect particles that go out of bounds
        lower_bound, upper_bound = -1, 1
        
        # Reflect from lower bound
        below_lower = self.particles < lower_bound
        self.particles[below_lower] = 2 * lower_bound - self.particles[below_lower]
        self.velocities[below_lower] *= -0.5
        
        # Reflect from upper bound
        above_upper = self.particles > upper_bound
        self.particles[above_upper] = 2 * upper_bound - self.particles[above_upper]
        self.velocities[above_upper] *= -0.5

class MultiModalFusionLayer(nn.Module):
    """Attention-based fusion of multiple modalities"""
    
    def __init__(self, 
                 text_dim: int,
                 behavioral_dim: int,
                 contextual_dim: int,
                 fusion_dim: int = 256,
                 num_heads: int = 8,
                 dropout_rate: float = 0.1):
        super().__init__()
        
        # Project all modalities to common dimension
        self.text_projection = nn.Linear(text_dim, fusion_dim)
        self.behavioral_projection = nn.Linear(behavioral_dim, fusion_dim)
        self.contextual_projection = nn.Linear(contextual_dim, fusion_dim)
        
        # Multi-head attention for fusion
        self.attention = nn.MultiheadAttention(
            embed_dim=fusion_dim,
            num_heads=num_heads,
            dropout=dropout_rate,
            batch_first=True
        )
        
        # Layer normalization
        self.layer_norm = nn.LayerNorm(fusion_dim)
        
        # Feed-forward network
        self.ffn = nn.Sequential(
            nn.Linear(fusion_dim, fusion_dim * 2),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(fusion_dim * 2, fusion_dim)
        )
        
        # Dropout
        self.dropout = nn.Dropout(dropout_rate)
    
    def forward(self, 
                text_features: torch.Tensor,
                behavioral_features: torch.Tensor,
                contextual_features: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Fuse multiple modalities using attention
        
        Args:
            text_features: Text features (batch_size, text_dim)
            behavioral_features: Behavioral features (batch_size, behavioral_dim)
            contextual_features: Contextual features (batch_size, contextual_dim)
            
        Returns:
            Tuple of (fused_features, attention_weights)
        """
        # Project to common dimension
        text_proj = self.text_projection(text_features).unsqueeze(1)
        behavioral_proj = self.behavioral_projection(behavioral_features).unsqueeze(1)
        contextual_proj = self.contextual_projection(contextual_features).unsqueeze(1)
        
        # Concatenate modalities: (batch_size, 3, fusion_dim)
        concatenated = torch.cat([text_proj, behavioral_proj, contextual_proj], dim=1)
        
        # Apply self-attention
        attended, attention_weights = self.attention(
            concatenated, concatenated, concatenated
        )
        
        # Residual connection and layer norm
        attended = self.layer_norm(concatenated + self.dropout(attended))
        
        # Feed-forward network
        fused = self.ffn(attended)
        
        # Global average pooling across modalities
        fused_pooled = fused.mean(dim=1)
        
        return fused_pooled, attention_weights

class TrustifyModel(nn.Module):
    """Complete Trustify model with CNN and APSO optimization"""
    
    def __init__(self,
                 vocab_size: int,
                 text_feature_dim: int = 300,
                 behavioral_feature_dim: int = 50,
                 contextual_feature_dim: int = 20,
                 num_classes: int = 2,
                 use_apso: bool = True):
        super().__init__()
        
        # Text encoder (CNN-based)
        self.text_encoder = CNNTextEncoder(
            vocab_size=vocab_size,
            embedding_dim=128,
            num_filters=100,
            filter_sizes=(3, 4, 5)
        )
        
        # Behavioral encoder
        self.behavioral_encoder = BehavioralEncoder(
            input_dim=behavioral_feature_dim,
            hidden_dims=(64, 32)
        )
        
        # Contextual encoder
        self.contextual_encoder = ContextualEncoder(
            input_dim=contextual_feature_dim,
            hidden_dims=(32, 16)
        )
        
        # Multi-modal fusion
        text_encoder_output_dim = 100 * 3  # num_filters * len(filter_sizes)
        self.fusion_layer = MultiModalFusionLayer(
            text_dim=text_encoder_output_dim,
            behavioral_dim=32,
            contextual_dim=16
        )
        
        # Classification head
        self.classifier = nn.Sequential(
            nn.Linear(256, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(64, num_classes)
        )
        
        # APSO optimizer for hyperparameter tuning
        self.use_apso = use_apso
        if use_apso:
            self.apso_optimizer = AdaptiveParticleSwarmOptimizer(
                num_particles=30,
                num_dimensions=10
            )
        
        # Attention weights storage for explainability
        self.attention_weights = None
    
    def forward(self, 
                text_indices: torch.Tensor,
                behavioral_features: torch.Tensor,
                contextual_features: torch.Tensor) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        """
        Forward pass through the complete model
        
        Args:
            text_indices: Text token indices (batch_size, seq_length)
            behavioral_features: Behavioral features (batch_size, behavioral_dim)
            contextual_features: Contextual features (batch_size, contextual_dim)
            
        Returns:
            Tuple of (logits, attention_weights_dict)
        """
        attention_weights = {}
        
        # Encode text
        text_encoded, text_attention = self.text_encoder(text_indices)
        attention_weights['text'] = text_attention
        
        # Encode behavioral features
        behavioral_encoded = self.behavioral_encoder(behavioral_features)
        
        # Encode contextual features
        contextual_encoded = self.contextual_encoder(contextual_features)
        
        # Fuse modalities
        fused_features, fusion_attention = self.fusion_layer(
            text_encoded, behavioral_encoded, contextual_encoded
        )
        attention_weights['fusion'] = fusion_attention
        
        # Classify
        logits = self.classifier(fused_features)
        
        # Store attention weights for explainability
        self.attention_weights = attention_weights
        
        return logits, attention_weights
    
    def optimize_with_apso(self, 
                          train_loader,
                          val_loader,
                          num_iterations: int = 50):
        """Optimize model hyperparameters using APSO"""
        if not self.use_apso:
            logger.warning("APSO optimization requested but not enabled")
            return
        
        def objective_function(hyperparams):
            """Objective function for APSO optimization"""
            # Extract hyperparameters from particle position
            learning_rate = 10 ** hyperparams[0]  # Log scale
            dropout_rate = 0.1 + 0.4 * (hyperparams[1] + 1) / 2  # [0.1, 0.5]
            weight_decay = 10 ** hyperparams[2]  # Log scale
            
            # Configure optimizer
            optimizer = torch.optim.AdamW(
                self.parameters(),
                lr=learning_rate,
                weight_decay=weight_decay
            )
            
            # Train for a few epochs
            self.train()
            for epoch in range(3):  # Quick evaluation
                total_loss = 0
                for batch in train_loader:
                    optimizer.zero_grad()
                    
                    # Forward pass
                    logits, _ = self(
                        batch['text_indices'],
                        batch['behavioral_features'],
                        batch['contextual_features']
                    )
                    
                    # Calculate loss
                    loss = F.cross_entropy(logits, batch['labels'])
                    
                    # Backward pass
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(self.parameters(), max_norm=1.0)
                    optimizer.step()
                    
                    total_loss += loss.item()
            
            # Evaluate on validation set
            self.eval()
            val_loss = 0
            with torch.no_grad():
                for batch in val_loader:
                    logits, _ = self(
                        batch['text_indices'],
                        batch['behavioral_features'],
                        batch['contextual_features']
                    )
                    loss = F.cross_entropy(logits, batch['labels'])
                    val_loss += loss.item()
            
            return val_loss / len(val_loader)
        
        # Run APSO optimization
        best_hyperparams = self.apso_optimizer.optimize(
            objective_function,
            max_iterations=num_iterations
        )
        
        logger.info(f"Best hyperparameters found: {best_hyperparams}")
        return best_hyperparams