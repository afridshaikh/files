import os
from transformers import AutoTokenizer, TFAutoModelForSequenceClassification

MODEL_NAME = "zayuki/computer_generated_fake_review_detection"
LOCAL_DIR = os.path.join("models", "fake-review")

os.makedirs(LOCAL_DIR, exist_ok=True)

print(f"📥 Downloading {MODEL_NAME} TensorFlow model and tokenizer...")
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = TFAutoModelForSequenceClassification.from_pretrained(MODEL_NAME)

print(f"💾 Saving to {LOCAL_DIR} ...")
tokenizer.save_pretrained(LOCAL_DIR)
model.save_pretrained(LOCAL_DIR)

print("✅ Done. Model and tokenizer saved locally.")
