import numpy as np

def evaluate_dose(base_predictions, dose_ratio, target_min=.20, target_max=.50):
    # Dose-response approximation: residual scales sublinearly with booster dose.
    pred=np.clip(base_predictions*(0.55+0.45*dose_ratio),0,2.5)
    compliance=((pred>=target_min)&(pred<=target_max)).mean()
    safety=(pred>=target_min).mean()
    cost=dose_ratio
    return {'dose_ratio':dose_ratio,'predicted_compliance':compliance,'safety_compliance':safety,'chlorine_cost_index':cost,'min_residual':pred.min(),'mean_residual':pred.mean()}

def optimize_dose(base_predictions, dose_min=.5, dose_max=1.1, steps=31, target_min=.2, target_max=.5):
    results=[evaluate_dose(base_predictions,d,target_min,target_max) for d in np.linspace(dose_min,dose_max,steps)]
    # Penalize non-compliance heavily, then minimize chemical cost.
    best=min(results,key=lambda r:(1-r['safety_compliance'])*100+r['chlorine_cost_index'])
    return best, results
