use studentDB

// Create
db.students.insertOne({name: "John", age: 20})
db.students.insertMany([{name: "Alice", age: 22}, {name: "Bob", age: 25}])

// Read
db.students.find()

// Update
db.students.updateOne({name: "John"}, {$set: {age: 21}})

// Delete
db.students.deleteOne({name: "John"})
