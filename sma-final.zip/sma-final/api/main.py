"""
api/main.py
===========
FastAPI backend.

POST /detect      → Stage 1: SMA detection from clinical features
POST /progression → Stage 2: Progression severity (only for SMA+ patients)
GET  /health      → model status
GET  /            → serve UI
"""

from pathlib import Path
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field

from api.stage1_service import (
    load as load_s1, predict as s1_predict, get_info as s1_info
)
from api.stage2_service import (
    load as load_s2, predict as s2_predict, get_info as s2_info
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    load_s1()
    load_s2()
    print("\n✅  Both models ready → http://localhost:8000\n")
    yield


app = FastAPI(title="SMA Detection & Progression", version="1.0.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware, allow_origins=["*"],
    allow_methods=["*"], allow_headers=["*"]
)


# ── Schemas ───────────────────────────────────────────────────────

class DetectionInput(BaseModel):
    patient_name:   str   = Field(..., min_length=1)
    age:            float = Field(..., ge=0,  le=100)
    gender:         int   = Field(..., ge=0,  le=1)
    smn1_copies:    int   = Field(..., ge=0,  le=5)
    smn2_copies:    int   = Field(..., ge=0,  le=6)
    eim_signal:     float = Field(..., ge=1,  le=100)
    ck_level:       float = Field(..., ge=10, le=2000)
    motor_score:    float = Field(..., ge=0,  le=100)
    weakness_score: float = Field(..., ge=0,  le=10)
    onset_age:      float = Field(..., ge=-1, le=80)
    family_history: int   = Field(..., ge=0,  le=1)
    fvc_percent:    float = Field(..., ge=5,  le=100)


class ProgressionInput(BaseModel):
    patient_name:        str   = Field(..., min_length=1)
    sma_type:            int   = Field(..., ge=1, le=4)
    smn2_copies:         int   = Field(..., ge=0, le=6)
    age_at_diagnosis:    float = Field(..., ge=0, le=80)
    time_since_diagnosis:float = Field(..., ge=0, le=360,
                                       description="Months since diagnosis")
    treatment_status:    int   = Field(..., ge=0, le=1,
                                       description="0=No treatment, 1=On DMT")
    motor_score:         float = Field(..., ge=0,  le=100)
    motor_trend:         float = Field(..., ge=-20, le=20,
                                       description="Motor score change per 6 months")
    fvc_percent:         float = Field(..., ge=5,  le=100)
    fvc_trend:           float = Field(..., ge=-20, le=20,
                                       description="FVC % change per 6 months")
    weakness_score:      float = Field(..., ge=0,  le=10)
    bulbar_score:        float = Field(..., ge=0,  le=10,
                                       description="Swallowing/speech function 0–10")


# ── Routes ────────────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
async def serve_ui():
    p = Path("ui/index.html")
    return HTMLResponse(p.read_text() if p.exists() else "<h2>ui/index.html not found</h2>")


@app.get("/health")
async def health():
    i1, i2 = s1_info(), s2_info()
    return {
        "status":       "ok",
        "stage1_model": i1.get("model_name", "not loaded"),
        "stage1_auc":   i1.get("auc"),
        "stage1_acc":   i1.get("accuracy"),
        "stage2_model": i2.get("model_name", "not loaded"),
        "stage2_auc":   i2.get("auc"),
        "stage2_acc":   i2.get("accuracy"),
    }


@app.post("/detect")
async def detect(req: DetectionInput):
    """Stage 1 — Detect whether patient has SMA."""
    try:
        result = s1_predict(req.model_dump())
    except FileNotFoundError as e:
        raise HTTPException(503, str(e))
    except Exception as e:
        raise HTTPException(500, f"Stage 1 error: {e}")
    return {"patient_name": req.patient_name, **result}


@app.post("/progression")
async def progression(req: ProgressionInput):
    """
    Stage 2 — Predict progression severity for a confirmed SMA patient.
    Frontend should only call this after Stage 1 confirms SMA.
    """
    try:
        result = s2_predict(req.model_dump())
    except FileNotFoundError as e:
        raise HTTPException(503, str(e))
    except Exception as e:
        raise HTTPException(500, f"Stage 2 error: {e}")
    return {"patient_name": req.patient_name, **result}
