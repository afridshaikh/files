from flask import Flask, request, make_response, url_for, jsonify
from flask_cors import CORS
app = Flask("first app")
CORS(app, resources={r"/*": {"origins": "*"}})
app.config['UPLOAD_FOLDER'] = "/Users/afridshaikh/Documents/projects/sessions/web/junk/files"

@app.route("/hello-world")
def hello():
    return "Hello World"

@app.route('/theme/<theme>')
def set_theme(theme):
    response = make_response("Cookie has been set!")
    response.set_cookie('theme', theme, max_age=5)
    return response



@app.route('/greet-with-theme')
def greet_with_cookie():
    theme = request.cookies.get('theme')
    if theme == "dark":
        return"""<h1 style="background-color: black; color: white;">Hello world</h1>"""
    return "<h1>Hello world</h1>"



@app.route("/submit-name", methods=["POST"])
def get_name_and_greet():
    name = request.form.get("user_name")
    return f"<h1>hello  {name}</h1>"


@app.route("/greet-with-name")
def greet():
    return """
        <form action="/submit-name" method="post">
        <input type="text" name="user_name"><br>
        <button type="submit">submit</button>
    </form>
    """




@app.route("/file-upload", methods=["GET", "POST"])
def upload():
    if request.method == "POST":
        files = request.files
        file = files["some_file"]
        file.save(app.config['UPLOAD_FOLDER'] + "/somefile")
        return str(files)
    if request.method == "GET":
        return '''
    <!doctype html>
    <title>Upload File</title>
    <h1>Upload New File</h1>
    <form method="post" enctype="multipart/form-data">
      <input type="file" name="some_file">
      <input type="submit" value="/file-upload">
    </form>
    '''




@app.route("/blog", methods=["POST"])
def blog():
    body = request.get_json()
    print("##### ",  body)
    return f"your blog is {body}"



@app.route("/blog/<id>")
def get_blog(id):
    return f"<h1> this is blog {id} </h1>"


@app.route("/blog/user/<user>/<blogid>")
def get_user_blog(user, blogid):
    url = url_for("get_blog", id=blogid)
    url1 = url_for("get_blog", id=blogid)
    url2 = url_for("get_blog", id=blogid)
    return f"""
    <h1> blog by {user} <a href="{url}">link</a> <br><a href="{url1}">link</a><br> <a href="{url2}">link</a></h1>
    """

@app.route("/users")
def get_users():
    users = [
        {
            "name": "John",
            "password": "john_pass",
            "age": 25
        },
        {
            "name": "Sara",
            "password": "sara_pass",
            "age": 27
        },
        {
            "name": "Bob",
            "password": "bob_pass",
            "age": 28
        },
        {
            "name": "Janice",
            "password": "janice_pass",
            "age": 26
        },
        {
            "name": "Alfred",
            "password": "alfred_pass",
            "age": 30
        }
    ]
    resp = make_response(jsonify(users))
    resp.headers['Access-Control-Allow-Origin'] = '*'
    resp.headers['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS'
    resp.headers['Content-Type'] = 'application/json'
    return resp


if __name__ == '__main__':
    app.run(debug=True)

