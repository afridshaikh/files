"""
api/stage2_service.py
=====================
Loads stage2_progression.pkl, predicts SMA disease progression severity.
Only called when Stage 1 has confirmed SMA detection.

Output:
  - Severity class: Mild / Moderate / Severe
  - Severity score: 0–100
  - Per-class probabilities
  - Key progression drivers
  - Clinical interpretation
"""

import os
import pandas as pd
import joblib

MODEL_PATH = "model/stage2_progression.pkl"

SEVERITY_LABELS  = {0: "Mild", 1: "Moderate", 2: "Severe"}
SEVERITY_COLORS  = {0: "green", 1: "amber", 2: "red"}

TREATMENT_LABELS = {
    0: "No treatment",
    1: "On disease-modifying therapy (nusinersen / risdiplam / gene therapy)"
}

INTERPRETATIONS = {
    0: (
        "Disease progression is currently classified as Mild. "
        "Motor and respiratory function are relatively preserved. "
        "Continue current management with regular monitoring."
    ),
    1: (
        "Disease progression is classified as Moderate. "
        "Declining trends in motor or respiratory function have been detected. "
        "Review treatment plan and consider escalation of therapy."
    ),
    2: (
        "Disease progression is classified as Severe. "
        "Significant deterioration in motor function, respiratory capacity, or both. "
        "Urgent multidisciplinary review recommended — consider ventilatory support "
        "and intensified disease-modifying therapy."
    ),
}

_bundle = None


def load():
    global _bundle
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(
            "model/stage2_progression.pkl not found.\n"
            "Run: python data/generate_data.py && python model/train.py"
        )
    _bundle = joblib.load(MODEL_PATH)
    print(f"✅  Stage 2 loaded: {_bundle['model_name']}  "
          f"AUC={_bundle['auc']}  Acc={_bundle['accuracy']*100:.1f}%")


def get_info():
    return {k: _bundle[k] for k in ("model_name", "auc", "accuracy")} if _bundle else {}


def predict(data: dict) -> dict:
    row   = pd.DataFrame([data])[_bundle["features"]]
    row_s = _bundle["scaler"].transform(row)
    proba = _bundle["model"].predict_proba(row_s)[0]
    pred  = int(proba.argmax())
    conf  = round(float(proba[pred]) * 100, 1)

    # Severity score 0–100 (weighted sum of class probabilities)
    severity_score = round(float(proba[1] * 50 + proba[2] * 100), 1)

    # Key drivers
    drivers = []

    smn2   = int(data.get("smn2_copies", 2))
    fvc    = float(data.get("fvc_percent", 80))
    fvc_t  = float(data.get("fvc_trend", 0))
    motor  = float(data.get("motor_score", 70))
    mot_t  = float(data.get("motor_trend", 0))
    treat  = int(data.get("treatment_status", 0))
    stype  = int(data.get("sma_type", 2))
    bulbar = float(data.get("bulbar_score", 8))
    t_dx   = float(data.get("time_since_diagnosis", 12))

    if smn2 <= 1:
        drivers.append("Low SMN2 copy count (1) — limited disease modifier")
    elif smn2 >= 3:
        drivers.append(f"SMN2 copies = {smn2} — moderating disease severity")

    if fvc < 60:
        drivers.append(f"Severely reduced FVC ({fvc}%) — significant respiratory compromise")
    elif fvc < 75:
        drivers.append(f"Reduced FVC ({fvc}%) — moderate respiratory involvement")

    if fvc_t < -3:
        drivers.append(f"Rapid FVC decline ({fvc_t}%/6mo) — worsening respiratory trend")
    elif fvc_t < 0:
        drivers.append(f"Mild FVC decline ({fvc_t}%/6mo)")
    elif fvc_t > 0:
        drivers.append(f"FVC improving ({fvc_t:+.1f}%/6mo) — positive respiratory trend")

    if motor < 50:
        drivers.append(f"Severely impaired motor function ({motor}/100)")
    elif motor < 70:
        drivers.append(f"Moderately reduced motor function ({motor}/100)")

    if mot_t < -3:
        drivers.append(f"Rapid motor decline ({mot_t}pts/6mo)")
    elif mot_t > 2:
        drivers.append(f"Motor function improving ({mot_t:+.1f}pts/6mo)")

    if not treat:
        drivers.append("Not currently on disease-modifying therapy")
    else:
        drivers.append("On disease-modifying therapy — positive prognostic factor")

    if bulbar < 6:
        drivers.append(f"Bulbar dysfunction (score {bulbar}/10) — swallowing/speech affected")

    return {
        "severity_class":  SEVERITY_LABELS[pred],
        "severity_index":  pred,
        "severity_score":  severity_score,
        "severity_color":  SEVERITY_COLORS[pred],
        "confidence":      conf,
        "probabilities": {
            "Mild":     round(float(proba[0]) * 100, 1),
            "Moderate": round(float(proba[1]) * 100, 1),
            "Severe":   round(float(proba[2]) * 100, 1),
        },
        "drivers":         drivers[:5],
        "interpretation":  INTERPRETATIONS[pred],
        "treatment_label": TREATMENT_LABELS[treat],
    }
