import numpy as np, pandas as pd
from src.data_simulator import SimConfig, build_network, simulate_sensor_data
from src.preprocessing import clean_sensor_data
from src.optimizer import optimize_dose

def test_network_and_data():
    c=SimConfig(start='2025-01-01',end='2025-01-01 03:45')
    nodes,pipes=build_network(c); df,_=simulate_sensor_data(c,nodes)
    assert len(nodes)==c.nodes and len(pipes)==c.pipes
    assert df.timestamp.nunique()==16
    assert df.chlorine_mg_l.notna().sum()>0

def test_cleaning_removes_missing():
    c=SimConfig(start='2025-01-01',end='2025-01-01 03:45')
    nodes,_=build_network(c); df,_=simulate_sensor_data(c,nodes); clean=clean_sensor_data(df)
    assert clean.chlorine_mg_l.notna().all()

def test_optimizer_returns_result():
    best,grid=optimize_dose(np.array([.15,.22,.30,.42,.55]))
    assert best['dose_ratio']>=.5 and len(grid)==31


def test_digital_twin_state_has_nodes_and_pipe_status():
    import pandas as pd
    from src.digital_twin import build_twin_state
    nodes = pd.DataFrame({
        'node_id':[0,1,2], 'x':[0.,1.,2.], 'y':[0.,0.,0.],
        'elevation_m':[10.,12.,14.], 'demand_lps':[0.,1.,1.],
        'pipe_material':['PVC']*3, 'diameter_mm':[100,100,100]
    })
    pipes = pd.DataFrame({'from_node':[0,1], 'to_node':[1,2], 'pipe_id':[0,1],
                          'length_m':[100.,100.], 'diameter_mm':[100,100],
                          'roughness':[120.,120.], 'material':['PVC','PVC']})
    chlorine = pd.DataFrame({'timestamp':pd.to_datetime(['2025-01-01']*2),
                              'node_id':[1,2], 'chlorine_mg_l':[0.3,0.1], 'water_age_h':[2.,5.]})
    telemetry = pd.DataFrame({'timestamp':pd.to_datetime(['2025-01-01']), 'pressure_bar_mean':[4.5]})
    ns, ps, ts = build_twin_state(nodes, pipes, chlorine, telemetry)
    assert len(ns) == 3
    assert len(ps) == 2
    assert {'chlorine_status','pressure_bar_est','is_sensor'}.issubset(ns.columns)
    assert 'estimated_status' in ps.columns
    assert str(ts).startswith('2025-01-01')
