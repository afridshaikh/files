const toggle = angular.module("toggle", [])


toggle.controller("Toggle", ["$scope", function($scope) {

    $scope.display = true

    $scope.displayText = function () {
        $scope.display = true
    }

    $scope.hideText = function () {
        $scope.display = false
    }

}])