from __future__ import annotations
import numpy as np
import pandas as pd
from dataclasses import dataclass

@dataclass
class SimConfig:
    seed: int = 42
    nodes: int = 200
    pipes: int = 260
    chlorine_sensors: int = 52
    ph_sensors: int = 38
    turbidity_sensors: int = 38
    temperature_sensors: int = 25
    flow_sensors: int = 87
    pressure_sensors: int = 87
    start: str = "2025-01-01 00:00"
    end: str = "2025-12-31 23:45"
    freq: str = "15min"
    base_chlorine: float = 0.72
    bulk_decay_per_day: float = 0.89
    wall_decay_per_day: float = 0.055
    booster_failure_start: str = "2025-03-15 08:00"
    booster_failure_minutes: int = 90
    missing_fraction: float = 0.005
    outlier_fraction: float = 0.001


def build_network(cfg: SimConfig) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Build a deterministic, street-grid-like distribution network.

    The layout uses a structured 10x20 junction grid with a source/reservoir at
    the west-side trunk. Main and secondary pipes follow corridors, with a few
    missing vertical links to create a plausible mixture of loops and branches.
    This is synthetic geometry, not a surveyed municipal network.
    """
    rng = np.random.default_rng(cfg.seed)
    n = int(cfg.nodes)
    if n != 200:
        # Keep topology predictable for arbitrary node counts by selecting a
        # near-square grid. The default research configuration is 10x20.
        rows = max(2, int(round(np.sqrt(n))))
        cols = int(np.ceil(n / rows))
    else:
        rows, cols = 10, 20
    positions = [(r, c) for r in range(rows) for c in range(cols)][:n]
    # Put the source at the west side, near the middle of the service area.
    source_pos = (min(rows - 1, max(0, rows // 2 - 1)), 0)
    positions.remove(source_pos)
    positions = [source_pos] + positions
    pos_to_id = {pos: i for i, pos in enumerate(positions)}
    spacing_x, spacing_y = 500.0, 500.0
    jitter_x = rng.normal(0, 24, n)
    jitter_y = rng.normal(0, 24, n)
    x = np.array([c * spacing_x for r, c in positions], dtype=float) + jitter_x
    y = np.array([r * spacing_y for r, c in positions], dtype=float) + jitter_y
    x[0], y[0] = -250.0, source_pos[0] * spacing_y
    elevation = 18 + np.array([r * 0.75 + c * 0.18 for r, c in positions]) + rng.normal(0, 1.5, n)
    demand = rng.uniform(0.5, 8.0, n)
    demand[0] = 0.0
    materials = rng.choice(["PVC", "DuctileIron", "CastIron", "LinedSteel"], n, p=[.40,.30,.20,.10])
    diameters = rng.choice([100, 150, 200, 250, 300, 400], n, p=[.15,.25,.25,.18,.12,.05])
    materials[0], diameters[0] = "DuctileIron", 400
    nodes = pd.DataFrame({
        "node_id": np.arange(n), "x": x, "y": y,
        "elevation_m": elevation, "demand_lps": demand,
        "pipe_material": materials, "diameter_mm": diameters,
        "node_type": ["SOURCE" if i == 0 else "JUNCTION" for i in range(n)],
        "grid_row": [r for r, c in positions], "grid_col": [c for r, c in positions],
    })

    edges = set()
    # Horizontal distribution mains across each street row.
    for r in range(rows):
        for c in range(cols - 1):
            a, b = pos_to_id.get((r, c)), pos_to_id.get((r, c + 1))
            if a is not None and b is not None:
                edges.add(tuple(sorted((a, b))))
    # Selected vertical corridors: dense around the trunk, sparse at the edge.
    vertical_cols = list(range(min(6, cols)))
    if cols > 6:
        vertical_cols += [6, 7]
    for c in vertical_cols:
        for r in range(rows - 1):
            if c >= 6 and r == rows - 2:
                continue
            a, b = pos_to_id.get((r, c)), pos_to_id.get((r + 1, c))
            if a is not None and b is not None:
                edges.add(tuple(sorted((a, b))))
    # Add/remove corridor links to match the configured pipe count while
    # preserving a connected, street-aligned topology.
    candidates = []
    for r in range(rows - 1):
        for c in range(cols):
            a, b = pos_to_id.get((r, c)), pos_to_id.get((r + 1, c))
            if a is not None and b is not None:
                candidates.append(tuple(sorted((a, b))))
    for edge in candidates:
        if len(edges) >= cfg.pipes:
            break
        edges.add(edge)
    edge_list = sorted(edges)
    if len(edge_list) > cfg.pipes:
        # Remove only redundant vertical links; horizontal rows remain intact.
        vertical = [e for e in edge_list if abs(positions[e[0]][0] - positions[e[1]][0]) == 1]
        keep = set(edge_list)
        for e in reversed(vertical):
            if len(keep) <= cfg.pipes:
                break
            keep.discard(e)
        edge_list = sorted(keep)
    # If an unusual configuration asks for more pipes, add nearest grid links.
    while len(edge_list) < cfg.pipes:
        possible = [(i, j) for i in range(n) for j in range(i + 1, n)
                    if tuple(sorted((i, j))) not in set(edge_list)
                    and abs(positions[i][0]-positions[j][0]) + abs(positions[i][1]-positions[j][1]) <= 2]
        if not possible:
            break
        edge_list.append(possible[0]); edge_list = sorted(set(edge_list))
    pipes = pd.DataFrame(edge_list[:cfg.pipes], columns=["from_node", "to_node"])
    pipes["pipe_id"] = np.arange(len(pipes))
    node_xy = nodes.set_index("node_id")[["x", "y"]]
    dx = pipes.from_node.map(node_xy.x) - pipes.to_node.map(node_xy.x)
    dy = pipes.from_node.map(node_xy.y) - pipes.to_node.map(node_xy.y)
    pipes["length_m"] = np.sqrt(dx**2 + dy**2).clip(lower=100).round(1)
    # Larger diameters on west-side trunk and major corridors.
    main_corridor = pipes.from_node.map(nodes.set_index("node_id").grid_col).le(2) | pipes.to_node.map(nodes.set_index("node_id").grid_col).le(2)
    pipes["diameter_mm"] = np.where(main_corridor, rng.choice([250, 300, 400], len(pipes)), rng.choice([100, 150, 200, 250], len(pipes)))
    pipes["roughness"] = np.where(main_corridor, rng.uniform(110, 145, len(pipes)), rng.uniform(85, 140, len(pipes))).round(1)
    pipes["material"] = rng.choice(["PVC", "DuctileIron", "CastIron", "LinedSteel"], len(pipes), p=[.4,.3,.2,.1])
    pipes["pipe_class"] = np.where(main_corridor, "DISTRIBUTION_MAIN", "DISTRIBUTION_BRANCH")
    return nodes, pipes


def _demand_pattern(ts: pd.DatetimeIndex) -> np.ndarray:
    hour = ts.hour + ts.minute / 60
    morning = np.exp(-0.5 * ((hour - 8.0) / 1.5) ** 2)
    evening = np.exp(-0.5 * ((hour - 18.0) / 1.8) ** 2)
    night = np.exp(-0.5 * ((hour - 3.0) / 2.0) ** 2)
    weekly = np.where(ts.dayofweek >= 5, 0.88, 1.0)
    return weekly * (0.55 + 0.95 * morning + 1.15 * evening - 0.15 * night)


def simulate_sensor_data(cfg: SimConfig, nodes: pd.DataFrame):
    """Generate the main chlorine dataset plus compact network-level SCADA telemetry.
    Keeping telemetry aggregated avoids producing tens of millions of rows while still
    representing the sensor streams described in the presentation.
    """
    rng = np.random.default_rng(cfg.seed + 10)
    ts = pd.date_range(cfg.start, cfg.end, freq=cfg.freq)
    n = len(ts)
    base = _demand_pattern(ts)
    day = np.arange(n) / 96.0
    seasonal = 1 + 0.08 * np.sin(2*np.pi*day/365)
    temp = 24 + 5*np.sin(2*np.pi*day/365) + 1.5*np.sin(2*np.pi*day/30) + rng.normal(0,.5,n)
    failure_start = pd.Timestamp(cfg.booster_failure_start)
    failure_end = failure_start + pd.Timedelta(minutes=cfg.booster_failure_minutes)
    failure = ((ts >= failure_start) & (ts <= failure_end)).astype(float)

    sensor_nodes = np.linspace(1, len(nodes)-1, cfg.chlorine_sensors, dtype=int)
    blocks=[]
    for node in sensor_nodes:
        dist=np.hypot(nodes.loc[node,'x']-5000,nodes.loc[node,'y']-5000)/7000
        k=cfg.bulk_decay_per_day*(0.85+0.35*dist)+cfg.wall_decay_per_day*(0.5+dist)
        age=0.8+10*dist+1.2*base
        chlorine=cfg.base_chlorine*(1-.75*failure)*np.exp(-k*age/24)
        chlorine += .035*np.sin(2*np.pi*day/7+dist*3)+rng.normal(0,.018,n)
        chlorine += .015*(temp-24)/10 - .10*(dist>.75)*base
        blocks.append(pd.DataFrame({'timestamp':ts,'node_id':node,'chlorine_mg_l':chlorine,'water_age_h':age,'temperature_c':temp,'booster_failure':failure}))
    chlorine=pd.concat(blocks,ignore_index=True)

    # Compact telemetry: one record per interval, representing fleet-level SCADA aggregates.
    demand_total=float(nodes.demand_lps.sum())
    flow_total=np.clip(demand_total*base*seasonal+rng.normal(0,demand_total*.015,n),0,None)
    pressure_mean=np.clip(4.8+.75*(base-.8)+rng.normal(0,.10,n),1.0,8.0)
    p5=7.35+.10*np.sin(2*np.pi*day/30)+rng.normal(0,.025,n)
    turb=np.clip(.65+.12*base+rng.normal(0,.05,n)+.9*failure,.05,None)
    telemetry=pd.DataFrame({'timestamp':ts,'flow_m3_h':flow_total*3.6,'pressure_bar_mean':pressure_mean,'pH_mean':p5,'turbidity_ntu_mean':turb,'temperature_c_mean':temp,'booster_failure':failure})

    # Apply a small amount of missingness/outliers to the main chlorine stream.
    idx=chlorine.sample(frac=cfg.missing_fraction,random_state=cfg.seed).index
    chlorine.loc[idx,'chlorine_mg_l']=np.nan
    idx=chlorine.sample(frac=cfg.outlier_fraction,random_state=cfg.seed+2).index
    chlorine.loc[idx,'chlorine_mg_l']*=.35
    return chlorine.sort_values(['timestamp','node_id']).reset_index(drop=True), telemetry
