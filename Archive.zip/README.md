# Water Quality Optimization – Synthetic Digital Twin + PINN

A runnable research/demo project based on the uploaded presentation **“Optimization of Water Quality Management in Drinking Water Distribution Network System using Computational Methods.”**

The project simulates a drinking-water distribution network, generates synthetic SCADA/water-quality observations, calibrates a simplified hydraulic/water-quality model, trains a Physics-Informed Neural Network (PINN) surrogate for chlorine residual, detects low-chlorine anomalies, and searches for a lower-dose operating point while preserving compliance.

> **Important:** The generated data are synthetic and are intended for software demonstration/research prototyping, not operational water-safety decisions.

## What is implemented

1. **Synthetic network** – configurable graph with junctions, reservoir, pipes and demand patterns.
2. **Synthetic SCADA** – 15-minute data for 12 months by default, including flow, pressure, chlorine, pH, turbidity and temperature.
3. **Data quality pipeline** – range checks, rate-of-change checks, missing-value injection, interpolation and IQR outlier handling.
4. **Physics-based water-quality model** – advection/decay-inspired chlorine model using bulk and wall decay coefficients.
5. **PINN surrogate** – predicts chlorine residual from hydraulic, spatial and water-quality features and includes a physics residual in the loss.
6. **Anomaly detection** – flags predicted/observed chlorine below 0.2 mg/L or abnormal turbidity.
7. **Optimization** – searches dosing settings to reduce chlorine consumption while improving compliance.
8. **Evaluation** – R², RMSE, MAE, NSE and PBIAS.
9. **Dashboard** – optional Streamlit dashboard for generated results.
10. **Tests** – basic tests for simulation, preprocessing and optimization.

## Project structure

```text
water_quality_optimization/
├── app.py
├── requirements.txt
├── README.md
├── config.yaml
├── src/
│   ├── data_simulator.py
│   ├── preprocessing.py
│   ├── physics.py
│   ├── pinn.py
│   ├── anomaly.py
│   ├── optimizer.py
│   └── metrics.py
├── wqo/
│   └── pipeline.py
├── data/
├── models/
├── reports/
├── tests/
└── notebooks/
```

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
python -m wqo.pipeline --mode demo
```

This creates synthetic data, trains a small demo PINN, evaluates it, detects anomalies and writes results under `data/`, `models/` and `reports/`.

### Generate the 12-month synthetic dataset only

```bash
python -m wqo.pipeline --mode data
```

### Faster demo

```bash
python -m wqo.pipeline --mode demo --epochs 300
```

### Larger PINN training

The presentation describes 50,000 epochs with Adam followed by L-BFGS. The project defaults to a much smaller number for a laptop demo. Increase `--epochs` when doing research experiments.

### Dashboard

```bash
pip install streamlit
streamlit run app.py
```

## Synthetic data design

The default configuration follows the presentation where possible:

- 12 months of data
- 15-minute resolution
- 52 chlorine monitoring locations
- 38 pH locations
- 38 turbidity locations
- 25 temperature locations
- 87 flow monitoring locations
- representative network with configurable node/pipe counts
- peak demand windows around 07:00–09:00 and 17:00–19:00
- chlorine target/residual compliance threshold of 0.2 mg/L
- bulk decay coefficient around 0.8–1.2 day⁻¹
- wall decay coefficient around 0.03–0.08 m/day

A simulated booster-failure event is injected into the data so the anomaly/response workflow can be demonstrated.

## Relationship to the presentation

The architecture follows the presentation's flow: physical/sensor layer → data validation and preprocessing → EPANET-style hydraulic/water-quality simulation → PINN surrogate → anomaly detection → optimization → reporting. The presentation reports a 12-month study, 52 chlorine monitoring locations, PINN input features, the advection-dispersion-reaction equation, and evaluation metrics; these are reflected in the configuration and implementation where practical.

## Research extensions

- Replace the synthetic topology with a real EPANET `.inp` network.
- Add WNTR/EPANET execution as a calibration backend.
- Add GNN/ST-GPINN architecture for explicit graph learning.
- Add uncertainty quantification.
- Add DBP/TTHM/HAA5 modelling.
- Add NSGA-II/Pareto optimization.
- Add sensor placement optimization.
- Compare PINN vs RF/XGBoost/GNN baselines.
