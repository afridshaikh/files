Aim: To implement expressions and built-in directives in AngularJS Framework

Objective:
- To use AngularJS expressions in HTML.
- To utilize built-in directives like ng-if, ng-repeat, etc.

Theory:
- What are AngularJS expressions and directives?
- How are ng-if and ng-repeat used in AngularJS?


Code:



Conclusion: 


---------------------------------
Instructions to run code:

- Save the code in a file named `directives.html`.

- Open the file in any modern web browser (Chrome/Firefox). `Right-click -> Open with -> Browser`

