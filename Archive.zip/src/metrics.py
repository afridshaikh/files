import numpy as np
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error

def metrics(y_true,y_pred):
    y_true=np.asarray(y_true); y_pred=np.asarray(y_pred)
    mse=mean_squared_error(y_true,y_pred)
    nse=1-np.sum((y_pred-y_true)**2)/np.sum((y_true-y_true.mean())**2)
    pbias=100*np.sum(y_pred-y_true)/np.sum(y_true)
    return {'R2':float(r2_score(y_true,y_pred)),'RMSE':float(np.sqrt(mse)),'MAE':float(mean_absolute_error(y_true,y_pred)),'NSE':float(nse),'PBIAS_percent':float(pbias)}
