Aim: To perform CRUD operation using MongoDB shell.

Objective:
- To perform Create, Read, Update, and Delete operations in MongoDB using shell commands.

Theory:
- What is MongoDB and its shell interface?
- How are CRUD operations executed in MongoDB?


Code:



Conclusion: 


---------------------------------
Instructions to run code:

- Open a new mongodb terminal

- Type or paste the provided shell commands step-by-step.

