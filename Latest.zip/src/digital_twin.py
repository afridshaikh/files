"""Lightweight graph-based pipeline digital twin for synthetic demonstration data.

This is a topology/state visualisation and simplified state estimator, not a calibrated
hydraulic solver. Use EPANET/WNTR before operational or engineering decisions.
"""
from __future__ import annotations
import numpy as np
import pandas as pd


def build_twin_state(nodes: pd.DataFrame, pipes: pd.DataFrame, chlorine: pd.DataFrame,
                     telemetry: pd.DataFrame, timestamp=None) -> tuple[pd.DataFrame, pd.DataFrame, pd.Timestamp]:
    """Create node/pipe state for the nearest available chlorine observation timestamp."""
    if chlorine.empty or telemetry.empty:
        raise ValueError("chlorine and telemetry data must not be empty")
    chlorine = chlorine.copy()
    telemetry = telemetry.copy()
    chlorine['timestamp'] = pd.to_datetime(chlorine['timestamp'])
    telemetry['timestamp'] = pd.to_datetime(telemetry['timestamp'])
    ts = pd.Timestamp(timestamp) if timestamp is not None else chlorine['timestamp'].max()
    available = chlorine.loc[chlorine.timestamp <= ts, 'timestamp']
    if available.empty:
        ts = chlorine['timestamp'].min()
    else:
        ts = available.max()
    cnow = chlorine[chlorine.timestamp == ts][['node_id','chlorine_mg_l','water_age_h']].copy()
    # Fill uninstrumented nodes with nearest monitored node in the synthetic coordinate plane.
    measured = nodes.merge(cnow, on='node_id', how='left')
    known = measured[measured.chlorine_mg_l.notna()]
    if known.empty:
        measured['chlorine_mg_l'] = 0.35
        measured['water_age_h'] = 4.0
    else:
        xy = known[['x','y']].to_numpy()
        all_xy = measured[['x','y']].to_numpy()
        # Network is deliberately small (200 nodes), so a simple distance matrix is fine.
        nearest = np.sqrt(((all_xy[:,None,:] - xy[None,:,:])**2).sum(axis=2)).argmin(axis=1)
        missing = measured.chlorine_mg_l.isna()
        measured.loc[missing, 'chlorine_mg_l'] = known.chlorine_mg_l.to_numpy()[nearest[missing.to_numpy()]]
        measured.loc[missing, 'water_age_h'] = known.water_age_h.to_numpy()[nearest[missing.to_numpy()]]
    tele = telemetry[telemetry.timestamp <= ts].tail(1)
    if tele.empty:
        tele = telemetry.head(1)
    t = tele.iloc[0]
    # State estimates are synthetic approximations for visualization only.
    measured['pressure_bar_est'] = np.clip(
        float(t.get('pressure_bar_mean', 4.5)) - (measured.elevation_m - measured.elevation_m.min()) * 0.012
        - measured.demand_lps * 0.018, 0.5, 8.0)
    measured['chlorine_status'] = np.where(measured.chlorine_mg_l < 0.2, 'LOW',
                                    np.where(measured.chlorine_mg_l > 0.5, 'HIGH', 'IN_RANGE'))
    measured['pressure_status'] = np.where(measured.pressure_bar_est < 1.5, 'LOW', 'OK')
    measured['is_sensor'] = measured.node_id.isin(cnow.node_id)
    pstate = pipes.copy()
    node_lookup = measured.set_index('node_id')
    pstate['from_chlorine_mg_l'] = pstate.from_node.map(node_lookup.chlorine_mg_l)
    pstate['to_chlorine_mg_l'] = pstate.to_node.map(node_lookup.chlorine_mg_l)
    pstate['chlorine_delta_mg_l'] = (pstate.from_chlorine_mg_l - pstate.to_chlorine_mg_l).abs()
    pstate['estimated_status'] = np.where(pstate.chlorine_delta_mg_l > 0.15, 'REVIEW', 'NORMAL')
    return measured, pstate, ts
