const utils = angular.module("utils", [])


utils.service("SortService", function(){
    this.sort = function(dataAsArray){
        return dataAsArray.sort()
    }
})