const index = angular.module("index", ["header", "footer"])

index.controller("Index", ["$scope", function($scope){

}])