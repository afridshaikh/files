# Water Quality Optimization + Pipeline Digital Twin

A runnable **synthetic-data research prototype** combining network topology, simplified pipeline/node state estimation, water-quality prediction, anomaly detection and chlorine-dose grid-search optimisation. It is designed for experimentation and is **not a calibrated engineering model or a real-time operational control system**.

## Included components

- Synthetic network generator: nodes and connecting pipes, materials, diameters, roughness and lengths.
- Synthetic 15-minute telemetry for chlorine, pressure, flow, pH, turbidity and temperature, including missing values, outliers and a booster-failure scenario.
- Preprocessing, a PyTorch PINN-style regressor, metrics, anomaly detection and dose-ratio grid search.
- **Pipeline digital twin:** node/pipe graph and a timestamped state snapshot. The dashboard renders pipe links, node chlorine state, estimated pressure, low-chlorine flags and pipe segments needing review.
- Small 7-day sample data for exploring formats without generating the full year.

## Important modelling boundary

The digital twin currently represents **topology + synthetic estimated state**. Node pressure is a transparent heuristic and chlorine at uninstrumented nodes is filled from the nearest sensor for visualisation. Pipe status is a simple chlorine-gradient review flag. The project does not solve hydraulic mass/energy balance and does not run EPANET/WNTR. Do not use its values to make drinking-water safety decisions. For a research-grade hydraulic twin, add an EPANET `.inp` network and use EPANET/WNTR simulation/calibration.

## Requirements

- Python 3.10 or 3.11 recommended
- 8 GB RAM recommended for the full year; more is helpful
- CPU works; a CUDA-capable GPU is optional

## Setup (macOS/Linux)

```bash
unzip water_quality_optimization_project.zip
cd water_quality_optimization
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Windows PowerShell activation: `.venv\\Scripts\\Activate.ps1`.

## Fast start: generate demo outputs and train briefly

```bash
python -m wqo.pipeline --mode demo --epochs 100
streamlit run app.py
```

Open the local URL printed by Streamlit (normally `http://localhost:8501`). A demo run generates data and reports into `data/`, `models/`, and `reports/`.

## Generate data only

```bash
python -m wqo.pipeline --mode data
```

This creates the synthetic year of sensor data and network topology, but skips PINN training and reports.

## Full PINN run

```bash
python -m wqo.pipeline --mode demo --epochs 500
```

For an initial smoke test, use `--epochs 5` or `--epochs 20`. The full-year data generation/training can take several minutes and use substantial memory.

## Explore included sample data

The `examples/demo_data/` directory contains a 7-day sample of synthetic chlorine and SCADA data plus network nodes/pipes. The dashboard uses generated files in `reports/` after a pipeline run, so run the fast-start command first.

## Outputs

- `data/network_nodes.csv`, `data/network_pipes.csv`
- `data/synthetic_chlorine_raw.csv`, `data/synthetic_chlorine_clean.csv`
- `data/synthetic_scada_telemetry.csv`
- `reports/pinn_metrics.json`, `reports/pinn_predictions.csv`
- `reports/anomaly_results.csv`, `reports/optimization.json`, `reports/run_summary.json`
- `reports/digital_twin_nodes.csv`, `reports/digital_twin_pipes.csv`

## Run tests

```bash
pytest -q
```

## Configuration

Edit `config.yaml` to change network size, dates, sensor counts, synthetic event, PINN settings and dose search range. Start/end and 15-minute frequency control the generated time span. Reducing the dates is recommended while developing.

## Suggested next research increment

1. Replace heuristic hydraulic state with EPANET/WNTR.
2. Calibrate pipe roughness and chlorine reaction coefficients against observations.
3. Add sensor uncertainty and confidence intervals.
4. Replace dose grid search with constrained NSGA-II Pareto optimisation.
5. Validate on real or independently generated test networks before making claims about operational performance.


### Digital-twin topology note
The default network is generated as a structured 10x20 street-grid-like layout, with a west-side source, horizontal distribution corridors, selected vertical mains, and larger pipe diameters on main corridors. Small coordinate jitter avoids perfectly artificial geometry while preserving readable street alignment. This is synthetic geometry, not a surveyed network.

### Dashboard dependency note
The observed-vs-predicted chart does not require `statsmodels`; it uses a standard Plotly scatter plot so the dashboard can run with the dependencies in `requirements.txt`.
