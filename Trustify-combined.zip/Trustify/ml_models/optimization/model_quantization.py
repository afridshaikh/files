# ml_models/optimization/model_quantization.py
import torch
import torch.nn as nn
import torch.quantization
from torch.quantization import QuantStub, DeQuantStub

class QuantizedTrustifyModel(nn.Module):
    """Quantized version of Trustify model for faster inference"""
    
    def __init__(self, original_model):
        super().__init__()
        
        # Copy architecture from original model
        self.text_encoder = original_model.text_encoder
        self.behavioral_encoder = original_model.behavioral_encoder
        self.contextual_encoder = original_model.contextual_encoder
        self.fusion_layer = original_model.fusion_layer
        self.classifier = original_model.classifier
        
        # Add quantization stubs
        self.quant = QuantStub()
        self.dequant = DeQuantStub()
    
    def forward(self, text_indices, behavioral_features, contextual_features):
        # Quantize inputs
        text_indices = self.quant(text_indices)
        behavioral_features = self.quant(behavioral_features.float())
        contextual_features = self.quant(contextual_features.float())
        
        # Original forward pass
        text_encoded, _ = self.text_encoder(text_indices)
        behavioral_encoded = self.behavioral_encoder(behavioral_features)
        contextual_encoded = self.contextual_encoder(contextual_features)
        
        fused_features, _ = self.fusion_layer(
            text_encoded, behavioral_encoded, contextual_encoded
        )
        
        logits = self.classifier(fused_features)
        
        # Dequantize output
        logits = self.dequant(logits)
        
        return logits, {}

def quantize_model(model, calibration_data):
    """Quantize model for inference optimization"""
    quantized_model = QuantizedTrustifyModel(model)
    
    # Set to evaluation mode
    quantized_model.eval()
    
    # Prepare for quantization
    quantized_model.qconfig = torch.quantization.get_default_qconfig('fbgemm')
    
    # Prepare model for quantization
    torch.quantization.prepare(quantized_model, inplace=True)
    
    # Calibrate with sample data
    with torch.no_grad():
        for batch in calibration_data:
            quantized_model(*batch)
    
    # Convert to quantized model
    torch.quantization.convert(quantized_model, inplace=True)
    
    return quantized_model

# ml_models/optimization/pruning.py
import torch.nn.utils.prune as prune

def prune_model(model, pruning_amount=0.3):
    """Prune model weights for efficiency"""
    parameters_to_prune = []
    
    # Identify prunable layers
    for name, module in model.named_modules():
        if isinstance(module, nn.Linear):
            parameters_to_prune.append((module, 'weight'))
    
    # Apply pruning
    prune.global_unstructured(
        parameters_to_prune,
        pruning_method=prune.L1Unstructured,
        amount=pruning_amount
    )
    
    # Make pruning permanent
    for module, param_name in parameters_to_prune:
        prune.remove(module, param_name)
    
    return model