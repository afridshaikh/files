import pandas as pd

def detect_anomalies(df, chlorine_threshold=.20, turbidity_threshold=3.0):
    x=df.copy()
    x['chlorine_anomaly']=x['chlorine_mg_l'] < chlorine_threshold
    x['turbidity_anomaly']=x['turbidity_ntu'] > turbidity_threshold if 'turbidity_ntu' in x else False
    x['anomaly']=x['chlorine_anomaly'] | x['turbidity_anomaly']
    return x
