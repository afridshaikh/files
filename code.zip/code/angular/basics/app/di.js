const di = angular.module("di", ["utils"])

di.controller("GetUsers", ["$scope", "SortService", function($scope, SortService){

    const users = ["Mat", "Jack", "Bob", "Alice"]

    $scope.sortedUsers = SortService.sort(users)


}])