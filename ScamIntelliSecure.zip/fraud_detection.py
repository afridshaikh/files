import os
import pathlib

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import SMOTE
import pickle
import json
from datetime import datetime
import warnings

warnings.filterwarnings('ignore')


class FraudDetectionModel:

    def __init__(self):
        self.model = None
        self.scaler = StandardScaler()
        self.feature_names = ['amount', 'time_hour', 'location_mismatch',
                              'merchant_risk', 'transaction_frequency', 'amount_deviation']
        model_folder = pathlib.Path(os.getcwd()).joinpath('model')
        model_folder.mkdir(parents=True, exist_ok=True)
        self.model_path = model_folder.__str__() + "/fraud_model.pkl"

    def get_training_data(self):
        path = "data/training.csv"
        return pd.read_csv(path)

    def preprocess_data(self, df):
        X = df[self.feature_names]
        y = df['is_fraud']
        X_scaled = self.scaler.fit_transform(X)
        return X_scaled, y

    def train_model(self):
        print("Reading sample data...")
        df = self.get_training_data()

        print("Preprocessing data...")
        X, y = self.preprocess_data(df)

        print("Applying SMOTE...")
        smote = SMOTE(random_state=42)
        X_resampled, y_resampled = smote.fit_resample(X, y)

        X_train, X_test, y_train, y_test = train_test_split(
            X_resampled, y_resampled, test_size=0.2, random_state=42, stratify=y_resampled
        )

        print("Training Random Forest model...")
        self.model = RandomForestClassifier(
            n_estimators=100,
            max_depth=10,
            min_samples_split=5,
            min_samples_leaf=2,
            random_state=42
        )

        self.model.fit(X_train, y_train)
        y_pred = self.model.predict(X_test)
        y_pred_proba = self.model.predict_proba(X_test)[:, 1]

        print("\nModel Performance:")
        print(f"Accuracy: {accuracy_score(y_test, y_pred):.4f}")
        print(f"Precision: {precision_score(y_test, y_pred):.4f}")
        print(f"Recall: {recall_score(y_test, y_pred):.4f}")
        print(f"F1-Score: {f1_score(y_test, y_pred):.4f}")
        print(f"ROC-AUC: {roc_auc_score(y_test, y_pred_proba):.4f}")

        with open(self.model_path, 'wb') as f:
            pickle.dump({'model': self.model, 'scaler': self.scaler}, f)

        print("Model saved as fraud_model.pkl")

    def predict_fraud(self, transaction_data):
        if self.model is None:
            with open(self.model_path, 'rb') as f:
                saved_data = pickle.load(f)
                self.model = saved_data['model']
                self.scaler = saved_data['scaler']

        features = np.array([[
            transaction_data['amount'],
            transaction_data['time_hour'],
            transaction_data['location_mismatch'],
            transaction_data['merchant_risk'],
            transaction_data['transaction_frequency'],
            transaction_data['amount_deviation']
        ]])

        features_scaled = self.scaler.transform(features)
        probability = self.model.predict_proba(features_scaled)[0][1]
        prediction = 1 if probability > 0.5 else 0

        return {
            'is_fraud': bool(prediction),
            'probability': float(probability),
            'timestamp': datetime.now().isoformat()
        }


if __name__ == "__main__":
    fraud = FraudDetectionModel()
    fraud.train_model()
