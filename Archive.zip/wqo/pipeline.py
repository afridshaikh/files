from __future__ import annotations
import argparse, json, os, yaml
import numpy as np, pandas as pd
from src.data_simulator import SimConfig, build_network, simulate_sensor_data
from src.preprocessing import clean_sensor_data
from src.pinn import train_pinn, predict
from src.metrics import metrics
from src.anomaly import detect_anomalies
from src.optimizer import optimize_dose

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--mode',choices=['data','demo'],default='demo'); ap.add_argument('--epochs',type=int,default=None); args=ap.parse_args()
    with open('config.yaml') as f: cfg=yaml.safe_load(f)
    s=cfg['simulation']; allowed=set(SimConfig.__dataclass_fields__); c=SimConfig(seed=cfg['seed'],**{k:v for k,v in s.items() if k in allowed})
    os.makedirs('data',exist_ok=True); os.makedirs('models',exist_ok=True); os.makedirs('reports',exist_ok=True)
    nodes,pipes=build_network(c); raw,telemetry=simulate_sensor_data(c,nodes); raw.to_csv('data/synthetic_chlorine_raw.csv',index=False); telemetry.to_csv('data/synthetic_scada_telemetry.csv',index=False)
    nodes.to_csv('data/network_nodes.csv',index=False); pipes.to_csv('data/network_pipes.csv',index=False)
    clean=clean_sensor_data(raw); clean.to_csv('data/synthetic_chlorine_clean.csv',index=False)
    print(f'Generated {len(raw):,} chlorine sensor records and {len(telemetry):,} network SCADA intervals.')
    if args.mode=='data': return
    # Use chlorine records as the PINN training set; add topology-derived features.
    ch=clean[clean.chlorine_mg_l.notna()].copy()
    stride=max(1, len(ch)//120000)
    ch=ch.iloc[::stride].copy()
    ch=ch.merge(telemetry[['timestamp','flow_m3_h','pressure_bar_mean','pH_mean','turbidity_ntu_mean','temperature_c_mean']], on='timestamp', how='left')
    node_meta=nodes.set_index('node_id')
    ch['distance_km']=np.hypot(node_meta.loc[ch.node_id,'x'].to_numpy()-5000,node_meta.loc[ch.node_id,'y'].to_numpy()-5000)/1000
    ch['diameter_mm']=node_meta.loc[ch.node_id,'diameter_mm'].to_numpy()
    ch['initial_chlorine']=c.base_chlorine*(1-ch.booster_failure.fillna(0)*.55)
    ch['pressure_bar']=ch['pressure_bar_mean'].fillna(4.0)
    ch['flow_lps']=ch['flow_m3_h'].fillna(10.0)/3.6
    ch['pH']=ch['pH_mean'].fillna(7.35)
    ch['temperature_c']=ch['temperature_c_mean'].fillna(24)
    ch['water_age_h']=ch['water_age_h'].fillna(4)
    cols=['flow_lps','pressure_bar','water_age_h','temperature_c','pH','initial_chlorine','diameter_mm','distance_km']
    X=ch[cols].to_numpy(dtype=np.float32); y=ch.chlorine_mg_l.to_numpy(dtype=np.float32)
    # Chronological split: 70/15/15 as in the presentation.
    split1=int(.70*len(ch)); split2=int(.85*len(ch))
    Xtr,ytr=X[:split1],y[:split1]; Xva,yva=X[split1:split2],y[split1:split2]; Xte,yte=X[split2:],y[split2:]
    # Standardise using training statistics.
    mu=Xtr.mean(0); sd=Xtr.std(0)+1e-6
    Xtrn=(Xtr-mu)/sd; Xvan=(Xva-mu)/sd; Xten=(Xte-mu)/sd
    epochs=args.epochs or cfg['pinn']['epochs']
    model,hist=train_pinn(Xtrn,ytr,epochs=epochs,batch_size=cfg['pinn']['batch_size'],lr=cfg['pinn']['learning_rate'],physics_weight=cfg['pinn']['physics_weight'],boundary_weight=cfg['pinn']['boundary_weight'],seed=cfg['seed'])
    import torch
    torch.save({'state_dict':model.state_dict(),'mu':mu,'sd':sd,'columns':cols},'models/pinn.pt')
    pred=predict(model,Xten); m=metrics(yte,pred)
    with open('reports/pinn_metrics.json','w') as f: json.dump(m,f,indent=2)
    pd.DataFrame({'actual':yte,'predicted':pred}).to_csv('reports/pinn_predictions.csv',index=False)
    # Anomaly report on all cleaned data.
    anomalies=detect_anomalies(clean); anomalies.to_csv('reports/anomaly_results.csv',index=False)
    # Optimize dose using a representative sample of test predictions.
    best, all_results=optimize_dose(pred, dose_min=cfg['optimizer']['dose_min'],dose_max=cfg['optimizer']['dose_max'],steps=cfg['optimizer']['dose_steps'],target_min=cfg['optimizer']['target_min'],target_max=cfg['optimizer']['target_max'])
    with open('reports/optimization.json','w') as f: json.dump({'best':best,'grid':all_results},f,indent=2)
    summary={'rows':len(raw),'chlorine_rows':int(len(ch)),'test_rows':len(yte),'metrics':m,'best_optimization':best,'anomaly_count':int(anomalies.anomaly.sum()),'note':'Synthetic demonstration only.'}
    with open('reports/run_summary.json','w') as f: json.dump(summary,f,indent=2)
    print(json.dumps(summary,indent=2))

if __name__=='__main__': main()
