from flask import Flask, request, jsonify
from flask_cors import CORS
from fraud_detection import FraudDetectionModel
import mysql.connector
from datetime import datetime
import os

app = Flask(__name__)
CORS(app)

fraud_model = FraudDetectionModel()

db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': 'mysql',
    'database': 'creditcardscam'
}


def create_table():
    create_table_query = """
    CREATE TABLE IF NOT EXISTS transactions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        card_number VARCHAR(50),
        amount DECIMAL(10,2),
        merchant VARCHAR(255),
        location VARCHAR(255),
        is_fraud BOOLEAN,
        probability DECIMAL(5,4),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(create_table_query)
    conn.commit()
    cursor.close()
    conn.close()


def get_db_connection():
    return mysql.connector.connect(**db_config)


@app.route('/')
def home():
    return jsonify({
        "message": "ScamIntelliSecure Fraud Detection API Running",
        "status": "OK"
    })


@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()

    required = ['card_number', 'amount', 'merchant', 'location']
    for r in required:
        if r not in data:
            return jsonify({"error": f"Missing field: {r}"}), 400

    transaction_data = {
        'card_number': data['card_number'],
        'amount': float(data['amount']),
        'time_hour': datetime.now().hour,
        'location_mismatch': int(data.get('location_mismatch', False)),
        'merchant_risk': data.get('merchant_risk', 0.1),
        'transaction_frequency': data.get('transaction_frequency', 2),
        'amount_deviation': data.get('amount_deviation', 0.1)
    }

    result = fraud_model.predict_fraud(transaction_data)

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO transactions (card_number, amount, merchant, location, is_fraud, probability, created_at)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
    """, (
        data['card_number'], data['amount'], data['merchant'], data['location'],
        result['is_fraud'], result['probability'], datetime.now()
    ))

    conn.commit()
    cursor.close()
    conn.close()

    return jsonify(result)


if __name__ == "__main__":
    create_table()
    if not os.path.exists("model/fraud_model.pkl"):
        fraud_model.train_model()

    app.run(debug=True)
