## Step 1:  Create Python virtual env
`` python -m venv .venv ``

## Step 2:  Activate Python virtual env

Linux \ MacOs 

``source .venv/Scripts/activate``

Windows 

`` .\.venv\Scripts\activate``

## Step 3:  Install dependencies

``pip install -r requirements.txt``

## Step 4:  Generate Data 
Skip this step if data is already there in ``data``folder

``python generate_data.py``


## Step 5:  Train Model 
Skip this step if model is already saved in ``model``folder

``python fraud_detection.py``

## Step 6:  Run Backend Server 
This will start api server which will accept requests for prediction

``python app.py``

## Step 7:  Open UI 
open below file in browser.

``index.html``

--------

## Instructions:

1. If you enter large amount its most likely perdict fraud.
2. If you select location other than below list, it might predict fraud (also highly depends on amount and location.
```
[ "mumbai", "pune", "delhi", "bangalore", "hyderabad", "india" ]
```
3. Below is the merchant risk factor mapping. If you select merchant with high risk, its more likely to predict fraud.
 ```
{
    "amazon": 0.1,
    "walmart": 0.2,
    "flipkart": 0.2,
    "online gaming": 0.7,
    "crypto exchange": 0.9,
    "international merchant": 0.8,
    "default": 0.5
}
 ```

---------
## Results
### Non Fraud Case
![Non Fraud Transaction](results/non-fraud.png)

### Fraud Case
![Non Fraud Transaction](results/fraud.png)