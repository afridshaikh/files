const header = angular.module("header", [])

header.controller("Header", ["$scope", function($scope){
    $scope.headerText = "Header"
}])