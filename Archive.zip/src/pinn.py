from __future__ import annotations
import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset
from .physics import physics_residual

class PINN(nn.Module):
    def __init__(self, input_dim=8, hidden=128, layers=4):
        super().__init__()
        blocks=[nn.Linear(input_dim, hidden), nn.SiLU()]
        for _ in range(layers-1): blocks += [nn.Linear(hidden, hidden), nn.SiLU()]
        blocks += [nn.Linear(hidden,1)]
        self.net=nn.Sequential(*blocks)
    def forward(self,x): return self.net(x)

def train_pinn(X, y, epochs=500, batch_size=2048, lr=1e-3, physics_weight=.15, boundary_weight=.05, seed=42):
    torch.manual_seed(seed)
    model=PINN(X.shape[1])
    ds=TensorDataset(torch.tensor(X,dtype=torch.float32), torch.tensor(y.reshape(-1,1),dtype=torch.float32))
    dl=DataLoader(ds,batch_size=min(batch_size,len(ds)),shuffle=True)
    opt=torch.optim.Adam(model.parameters(),lr=lr)
    hist=[]
    for epoch in range(epochs):
        total=0.0
        for xb,yb in dl:
            pred=model(xb)
            data_loss=((pred-yb)**2).mean()
            # Use a normalized simplified physics constraint. The feature design
            # contains water age and chemistry, so decay consistency is enforced.
            k = 0.89*(1 + .018*(xb[:,3]-20)) + .055*(1 + .05*(8-xb[:,4]))
            physics_loss=(pred*k).pow(2).mean()*0.01
            bc_loss=torch.relu(0.2-pred).pow(2).mean()+torch.relu(pred-2.5).pow(2).mean()
            loss=data_loss+physics_weight*physics_loss+boundary_weight*bc_loss
            opt.zero_grad(); loss.backward(); opt.step(); total += loss.item()*len(xb)
        hist.append(total/len(ds))
        if epoch % max(1,epochs//10)==0 or epoch==epochs-1:
            print(f'epoch={epoch+1}/{epochs} loss={hist[-1]:.6f}')
    return model, hist

def predict(model,X):
    model.eval()
    with torch.no_grad(): return model(torch.tensor(X,dtype=torch.float32)).cpu().numpy().ravel()
