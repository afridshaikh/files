# tests/test_trustify.py
import unittest
import torch
import numpy as np
from ml_models.cnn_apso.model import TrustifyModel, CNNTextEncoder
from ml_models.training.trainer import TrustifyTrainer
from preprocessing.text_processor import AdvancedTextProcessor
x
class TestTrustifyComponents(unittest.TestCase):
    """Unit tests for Trustify components"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.vocab_size = 1000
        self.batch_size = 4
        self.seq_length = 50
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    def test_cnn_text_encoder(self):
        """Test CNN text encoder"""
        encoder = CNNTextEncoder(vocab_size=self.vocab_size)
        
        # Create dummy input
        text_indices = torch.randint(0, self.vocab_size, (self.batch_size, self.seq_length))
        
        # Forward pass
        features, attention = encoder(text_indices)
        
        # Check output dimensions
        expected_features_dim = 100 * 3  # num_filters * len(filter_sizes)
        self.assertEqual(features.shape, (self.batch_size, expected_features_dim))
        
        # Check attention weights
        self.assertIsNotNone(attention)
    
    def test_trustify_model_forward(self):
        """Test complete Trustify model forward pass"""
        model = TrustifyModel(
            vocab_size=self.vocab_size,
            text_feature_dim=300,
            behavioral_feature_dim=50,
            contextual_feature_dim=20
        )
        
        # Create dummy inputs
        text_indices = torch.randint(0, self.vocab_size, (self.batch_size, self.seq_length))
        behavioral_features = torch.randn(self.batch_size, 50)
        contextual_features = torch.randn(self.batch_size, 20)
        
        # Forward pass
        logits, attention_weights = model(
            text_indices, behavioral_features, contextual_features
        )
        
        # Check outputs
        self.assertEqual(logits.shape, (self.batch_size, 2))  # 2 classes
        self.assertIsInstance(attention_weights, dict)
        self.assertIn('text', attention_weights)
        self.assertIn('fusion', attention_weights)
    
    def test_text_processor(self):
        """Test text preprocessing"""
        processor = AdvancedTextProcessor()
        test_text = "This is a test review! It has multiple sentences. Third one here."
        
        # Process text
        result = processor.process(test_text)
        
        # Check results
        self.assertIsInstance(result.tokens, list)
        self.assertIsInstance(result.sentences, list)
        self.assertIsInstance(result.linguistic_features, dict)
        self.assertGreater(len(result.sentences), 1)
        
        # Check linguistic features
        expected_features = ['num_chars', 'num_words', 'num_sentences']
        for feature in expected_features:
            self.assertIn(feature, result.linguistic_features)
    
    def test_model_training_step(self):
        """Test model training step"""
        model = TrustifyModel(vocab_size=self.vocab_size)
        model.to(self.device)
        
        # Create dummy batch
        batch = {
            'text_indices': torch.randint(0, self.vocab_size, (self.batch_size, self.seq_length)).to(self.device),
            'behavioral_features': torch.randn(self.batch_size, 50).to(self.device),
            'contextual_features': torch.randn(self.batch_size, 20).to(self.device),
            'labels': torch.randint(0, 2, (self.batch_size,)).to(self.device)
        }
        
        # Create optimizer
        optimizer = torch.optim.AdamW(model.parameters(), lr=0.001)
        
        # Training step
        model.train()
        optimizer.zero_grad()
        
        logits, _ = model(
            batch['text_indices'],
            batch['behavioral_features'],
            batch['contextual_features']
        )
        
        loss = torch.nn.functional.cross_entropy(logits, batch['labels'])
        loss.backward()
        optimizer.step()
        
        # Check that loss is computed
        self.assertIsInstance(loss.item(), float)
        self.assertGreater(loss.item(), 0)
    
    def test_apso_optimizer(self):
        """Test APSO optimizer"""
        from ml_models.cnn_apso.model import AdaptiveParticleSwarmOptimizer
        
        # Simple objective function (sphere function)
        def sphere_function(x):
            return np.sum(x**2)
        
        optimizer = AdaptiveParticleSwarmOptimizer(
            num_particles=10,
            num_dimensions=5
        )
        
        # Run optimization
        best_solution = optimizer.optimize(sphere_function, max_iterations=20)
        
        # Check results
        self.assertEqual(best_solution.shape, (5,))
        self.assertLess(np.sum(best_solution**2), 0.1)  # Should optimize toward zero
    
    def test_feature_extraction(self):
        """Test feature extraction pipeline"""
        from preprocessing.feature_extractor import FeatureExtractor
        
        extractor = FeatureExtractor()
        
        # Create dummy review data
        review_data = {
            'review_text': 'Excellent product! Highly recommended.',
            'rating': 5.0,
            'review_date': '2024-01-15T10:30:00',
            'product_avg_rating': 4.2,
            'reviewer_total_reviews': 3,
            'verified_purchase': True,
            'platform': 'amazon'
        }
        
        # Extract features
        features = extractor.extract_features(review_data)
        
        # Check feature types
        self.assertIsInstance(features, dict)
        
        # Check specific features
        expected_features = ['rating', 'rating_extreme', 'review_hour']
        for feature in expected_features:
            self.assertIn(feature, features)
    
    def test_model_inference_speed(self):
        """Test model inference speed"""
        model = TrustifyModel(vocab_size=self.vocab_size)
        model.eval()
        
        # Warm up
        dummy_input = (
            torch.randint(0, self.vocab_size, (1, 100)),
            torch.randn(1, 50),
            torch.randn(1, 20)
        )
        
        with torch.no_grad():
            for _ in range(10):
                model(*dummy_input)
        
        # Benchmark inference
        import time
        start_time = time.time()
        
        with torch.no_grad():
            for _ in range(100):
                model(*dummy_input)
        
        end_time = time.time()
        avg_inference_time = (end_time - start_time) / 100
        
        # Check that inference is fast
        self.assertLess(avg_inference_time, 0.1)  # Should be less than 100ms
    
    def test_multi_modal_fusion(self):
        """Test multi-modal fusion layer"""
        from ml_models.cnn_apso.model import MultiModalFusionLayer
        
        fusion_layer = MultiModalFusionLayer(
            text_dim=300,
            behavioral_dim=32,
            contextual_dim=16
        )
        
        # Create dummy features
        batch_size = 4
        text_features = torch.randn(batch_size, 300)
        behavioral_features = torch.randn(batch_size, 32)
        contextual_features = torch.randn(batch_size, 16)
        
        # Forward pass
        fused_features, attention_weights = fusion_layer(
            text_features, behavioral_features, contextual_features
        )
        
        # Check outputs
        self.assertEqual(fused_features.shape, (batch_size, 256))
        self.assertIsNotNone(attention_weights)

class IntegrationTests(unittest.TestCase):
    """Integration tests for the complete pipeline"""
    
    def test_end_to_end_prediction(self):
        """Test complete end-to-end prediction pipeline"""
        # This would test the complete flow from raw review to prediction
        pass
    
    def test_api_endpoints(self):
        """Test API endpoints"""
        # This would test the Flask API endpoints
        pass

if __name__ == '__main__':
    unittest.main()