Aim: To implement TypeScript program to display Hello Word message on console

Objective: 
- To understand basic syntax and setup of a TypeScript program.
- To run and compile a TypeScript file.

Theory:
- How is TypeScript different from JavaScript?
- What are the steps to run a TypeScript program?

Code:



Conclusion: 


-------------------------------
Instructions to run code:

- Install TypeScript globally (if not already):
`npm install -g typescript`

- Save the code in a file named 
`hello.ts`

- Compile the code using:
`tsc hello.ts`

- Run the generated hello.js using Node.js:
`node hello.js`