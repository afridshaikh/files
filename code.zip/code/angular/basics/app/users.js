/**
 * 
 *  1) listUserApp.service: here we declared a service in module. Service is usually used to perform some operations for module like
 *      fetch data, authenticate, perform some computation. 
 *  2) this.GetUserData : we declared a function within our service which returns data
 * 
 *  3) ListUserApp: this controller needs user data. so we injected service via dependency injection and call GetUserData function
 * 
 * 
 */
const listUserApp = angular.module("listUserApp", [])

listUserApp.service('GetUsers', function () {
    this.GetUserData = function () {
        return [
            {
                "age": 25,
                "name": "John",
                "password": "john_pass"
            },
            {
                "age": 27,
                "name": "Sara",
                "password": "sara_pass"
            },
            {
                "age": 28,
                "name": "Bob",
                "password": "bob_pass"
            },
            {
                "age": 26,
                "name": "Janice",
                "password": "janice_pass"
            },
            {
                "age": 30,
                "name": "Alfred",
                "password": "alfred_pass"
            }
        ]
    }
})


listUserApp.controller("ListUserApp", ['$scope', 'GetUsers', function ($scope, GetUsers) {
    $scope.users = GetUsers.GetUserData()

}])

