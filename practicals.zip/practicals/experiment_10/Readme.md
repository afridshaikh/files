Aim: To create an application for AJAX: To fetch data when button is clicked.

Objective:
- To use AJAX for asynchronous data fetching.
- To update webpage content dynamically without reloading.



Theory:
- What is AJAX and how does it work in the browser?
- How can AJAX be implemented using JavaScript?


Code:



Conclusion: 


---------------------------------
Instructions to run code:

- Create two files: `index.html` (with the AJAX code)

- Open `index.html` in a browser.

- Click the button to load content from API.

