from __future__ import annotations
import numpy as np
import pandas as pd
from dataclasses import dataclass

@dataclass
class SimConfig:
    seed: int = 42
    nodes: int = 200
    pipes: int = 260
    chlorine_sensors: int = 52
    ph_sensors: int = 38
    turbidity_sensors: int = 38
    temperature_sensors: int = 25
    flow_sensors: int = 87
    pressure_sensors: int = 87
    start: str = "2025-01-01 00:00"
    end: str = "2025-12-31 23:45"
    freq: str = "15min"
    base_chlorine: float = 0.72
    bulk_decay_per_day: float = 0.89
    wall_decay_per_day: float = 0.055
    booster_failure_start: str = "2025-03-15 08:00"
    booster_failure_minutes: int = 90
    missing_fraction: float = 0.005
    outlier_fraction: float = 0.001


def build_network(cfg: SimConfig) -> tuple[pd.DataFrame, pd.DataFrame]:
    rng = np.random.default_rng(cfg.seed)
    nodes = pd.DataFrame({
        "node_id": np.arange(cfg.nodes),
        "x": rng.uniform(0, 10000, cfg.nodes),
        "y": rng.uniform(0, 10000, cfg.nodes),
        "elevation_m": rng.uniform(5, 55, cfg.nodes),
        "demand_lps": rng.uniform(0.5, 8.0, cfg.nodes),
        "pipe_material": rng.choice(["PVC", "DuctileIron", "CastIron", "LinedSteel"], cfg.nodes, p=[.40,.30,.20,.10]),
        "diameter_mm": rng.choice([100,150,200,250,300,400], cfg.nodes)
    })
    # Force node 0 to represent treatment/reservoir source.
    nodes.loc[0, ["x", "y", "elevation_m", "demand_lps"]] = [5000, 5000, 60, 0]
    edges = []
    # Spanning-tree backbone.
    for i in range(1, cfg.nodes):
        j = rng.integers(0, i)
        edges.append((j, i))
    while len(edges) < cfg.pipes:
        a, b = rng.choice(cfg.nodes, 2, replace=False)
        if a > b: a, b = b, a
        if (a, b) not in edges: edges.append((a, b))
    pipes = pd.DataFrame(edges, columns=["from_node", "to_node"])
    pipes["pipe_id"] = np.arange(len(pipes))
    pipes["length_m"] = rng.uniform(100, 1200, len(pipes))
    pipes["diameter_mm"] = rng.choice([100,150,200,250,300,400], len(pipes))
    pipes["roughness"] = rng.uniform(80, 145, len(pipes))
    pipes["material"] = rng.choice(["PVC", "DuctileIron", "CastIron", "LinedSteel"], len(pipes), p=[.4,.3,.2,.1])
    return nodes, pipes


def _demand_pattern(ts: pd.DatetimeIndex) -> np.ndarray:
    hour = ts.hour + ts.minute / 60
    morning = np.exp(-0.5 * ((hour - 8.0) / 1.5) ** 2)
    evening = np.exp(-0.5 * ((hour - 18.0) / 1.8) ** 2)
    night = np.exp(-0.5 * ((hour - 3.0) / 2.0) ** 2)
    weekly = np.where(ts.dayofweek >= 5, 0.88, 1.0)
    return weekly * (0.55 + 0.95 * morning + 1.15 * evening - 0.15 * night)


def simulate_sensor_data(cfg: SimConfig, nodes: pd.DataFrame):
    """Generate the main chlorine dataset plus compact network-level SCADA telemetry.
    Keeping telemetry aggregated avoids producing tens of millions of rows while still
    representing the sensor streams described in the presentation.
    """
    rng = np.random.default_rng(cfg.seed + 10)
    ts = pd.date_range(cfg.start, cfg.end, freq=cfg.freq)
    n = len(ts)
    base = _demand_pattern(ts)
    day = np.arange(n) / 96.0
    seasonal = 1 + 0.08 * np.sin(2*np.pi*day/365)
    temp = 24 + 5*np.sin(2*np.pi*day/365) + 1.5*np.sin(2*np.pi*day/30) + rng.normal(0,.5,n)
    failure_start = pd.Timestamp(cfg.booster_failure_start)
    failure_end = failure_start + pd.Timedelta(minutes=cfg.booster_failure_minutes)
    failure = ((ts >= failure_start) & (ts <= failure_end)).astype(float)

    sensor_nodes = np.linspace(1, len(nodes)-1, cfg.chlorine_sensors, dtype=int)
    blocks=[]
    for node in sensor_nodes:
        dist=np.hypot(nodes.loc[node,'x']-5000,nodes.loc[node,'y']-5000)/7000
        k=cfg.bulk_decay_per_day*(0.85+0.35*dist)+cfg.wall_decay_per_day*(0.5+dist)
        age=0.8+10*dist+1.2*base
        chlorine=cfg.base_chlorine*(1-.75*failure)*np.exp(-k*age/24)
        chlorine += .035*np.sin(2*np.pi*day/7+dist*3)+rng.normal(0,.018,n)
        chlorine += .015*(temp-24)/10 - .10*(dist>.75)*base
        blocks.append(pd.DataFrame({'timestamp':ts,'node_id':node,'chlorine_mg_l':chlorine,'water_age_h':age,'temperature_c':temp,'booster_failure':failure}))
    chlorine=pd.concat(blocks,ignore_index=True)

    # Compact telemetry: one record per interval, representing fleet-level SCADA aggregates.
    demand_total=float(nodes.demand_lps.sum())
    flow_total=np.clip(demand_total*base*seasonal+rng.normal(0,demand_total*.015,n),0,None)
    pressure_mean=np.clip(4.8+.75*(base-.8)+rng.normal(0,.10,n),1.0,8.0)
    p5=7.35+.10*np.sin(2*np.pi*day/30)+rng.normal(0,.025,n)
    turb=np.clip(.65+.12*base+rng.normal(0,.05,n)+.9*failure,.05,None)
    telemetry=pd.DataFrame({'timestamp':ts,'flow_m3_h':flow_total*3.6,'pressure_bar_mean':pressure_mean,'pH_mean':p5,'turbidity_ntu_mean':turb,'temperature_c_mean':temp,'booster_failure':failure})

    # Apply a small amount of missingness/outliers to the main chlorine stream.
    idx=chlorine.sample(frac=cfg.missing_fraction,random_state=cfg.seed).index
    chlorine.loc[idx,'chlorine_mg_l']=np.nan
    idx=chlorine.sample(frac=cfg.outlier_fraction,random_state=cfg.seed+2).index
    chlorine.loc[idx,'chlorine_mg_l']*=.35
    return chlorine.sort_values(['timestamp','node_id']).reset_index(drop=True), telemetry
