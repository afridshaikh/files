
const routeApp = angular.module("routeApp", ['ngRoute'])


routeApp.config(['$routeProvider', '$locationProvider', function($routeProvider, $locationProvider) {

    $locationProvider.hashPrefix('');

    $routeProvider
    .when('/home', {
        templateUrl: 'templates/home.html',
        controller: 'HomeController'
    }).when('/view-click', {
        templateUrl: 'templates/header.html',
        controller: 'HeaderController'
    }).otherwise({
        redirectTo: '/home'
    })
}])

routeApp.controller("HeaderController", ['$scope', function($scope){}])

routeApp.controller("HomeController", ['$scope', function($scope){}])