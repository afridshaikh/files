from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from ml_models.model import load_model, predict_review, create_lime_explanation

app = Flask(__name__)
CORS(app)

print("🤖 Loading model from local disk...")
model, tokenizer, lime_explainer = load_model()
print("✅ Model loaded and ready.")


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/analyze", methods=["POST"])
def analyze_review():
    try:
        data = request.json or {}
        text = data.get("text", "")

        if not text.strip():
            return jsonify({
                "success": False,
                "error": "Empty review text"
            }), 400

        results = predict_review(text, model, tokenizer)
        lime_html = create_lime_explanation(text, model, tokenizer, lime_explainer)

        return jsonify({
            "success": True,
            "results": results,
            "lime_explanation": lime_html
        })
    except Exception as e:
        print("❌ Error in /api/analyze:", e)
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    # Run with: python app.py  then open http://localhost:5000
    app.run(host="0.0.0.0", port=5000, debug=True)
