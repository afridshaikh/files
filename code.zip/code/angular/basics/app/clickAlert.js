const clickAlert =  angular.module("clickAlert", [])

clickAlert.controller("ClickAlert", ["$scope", function($scope){
    $scope.clickAction = function(){
        alert("button is clicked!")
    }
}])
