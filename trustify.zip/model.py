import os
import numpy as np
from transformers import AutoTokenizer, TFAutoModelForSequenceClassification
from lime.lime_text import LimeTextExplainer

MODEL_DIR = os.path.join(os.path.dirname(__file__), "models", "zayuki-fake-review")


def load_model():
    """
    Load tokenizer, TensorFlow classifier, and LIME explainer from local models directory.
    Run download_zayuki_model.py once before this so MODEL_DIR is populated.
    """
    tokenizer = AutoTokenizer.from_pretrained(MODEL_DIR, local_files_only=True)
    model = TFAutoModelForSequenceClassification.from_pretrained(
        MODEL_DIR,
        local_files_only=True
    )

    id2label = model.config.id2label
    class_names = [id2label[i] for i in sorted(id2label.keys())]

    # lime_explainer = LimeTextExplainer(class_names=class_names)
    lime_explainer = LimeTextExplainer(class_names=["Genuine", "Fake"])
    return model, tokenizer, lime_explainer


def bert_score(text: str, model, tokenizer) -> float:
    """
    Get P(fake/generated) from the TF zayuki model.
    Assumes logits[1] corresponds to fake/generated.
    """
    enc = tokenizer(
        text,
        return_tensors="tf",
        truncation=True,
        padding=True,
        max_length=512
    )
    outputs = model(enc)
    logits = outputs.logits.numpy()[0]
    probs = np.exp(logits) / np.exp(logits).sum(-1, keepdims=True)
    p_fake = float(probs[1])
    return p_fake


def predict_review(text: str, model, tokenizer):
    fake_prob = bert_score(text, model, tokenizer)
    fake_prob = max(0.0, min(1.0, fake_prob))
    genuine_prob = 1.0 - fake_prob
    label = "Fake" if fake_prob >= 0.5 else "Genuine"

    return {
        "label": label,
        "fake_confidence": fake_prob,
        "genuine_confidence": genuine_prob
    }


def create_lime_explanation(text: str, model, tokenizer, lime_explainer):
    """
    Generate LIME HTML explanation for the zayuki TF classifier.
    """

    def predict_proba(texts):
        all_probs = []
        for t in texts:
            if not t.strip():
                all_probs.append([0.5, 0.5])
                continue

            enc = tokenizer(
                t,
                return_tensors="tf",
                truncation=True,
                padding=True,
                max_length=512
            )
            outputs = model(enc)
            logits = outputs.logits.numpy()[0]
            probs = np.exp(logits) / np.exp(logits).sum(-1, keepdims=True)
            all_probs.append([float(probs[0]), float(probs[1])])  # [real, fake]

        return np.array(all_probs)

    explanation = lime_explainer.explain_instance(
        text,
        predict_proba,
        num_features=10,
        num_samples=1000
    )
    return explanation.as_html()
