Aim: Implement classes and Inheritance in TypeScript

Objective:
- To understand object-oriented programming using TypeScript.
- To implement inheritance between classes.

Theory:
- How is class-based OOP implemented in TypeScript?
- What is inheritance and how is it used?


Code:



Conclusion: 


---------------------------------
Instructions to run code:

- Save the code in a file named `classInheritance.ts`.

- Compile using TypeScript compiler: `tsc classInheritance.ts`

- Run the compiled file: `node classInheritance.js`