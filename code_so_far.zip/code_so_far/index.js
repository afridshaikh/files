// import { MongoClient, ObjectId } from "mongodb";


// const uri = "mongodb://adminuser:admin@localhost:27017";

// const client = new MongoClient(uri);

// try {
//     client.connect()
// } catch (error) {
//     console.log({error})
// }


// const db = client.db("newdb");
// // console.log("connected ...")
// // for(let i=0; i< 3; i+=1){
//     db.collection("users").insertOne({ name: "John", age: 24 });
// // }
// console.log("inserted")
// const users = await db.collection("users").find().toArray()
// console.log("users ", {users})
// await db.collection("users").updateOne({_id: new ObjectId("67f03d4c7a532164a9200ecd")},  { $set : { age: 25}})


// await db.collection("users").deleteMany({age: {$gt: 24}})








import {mongoose} from "mongoose"
const mongooseUri = "mongodb://adminuser:admin@localhost:27017" +
                            "/newdb?authSource=admin";
mongoose.connect(mongooseUri)

const userSchema = mongoose.Schema({
    name: { type: String, required: true},
    age: Number,
    email: { type: String, required: true, unique: true}
})
const user = mongoose.model('user', userSchema)


const userCrated = await user.create({ name: "Sara", age: 20, email: "sara6@example.com" });

console.log(userCrated)

// user     age email
// alice    25  alice@test.com
// bob      20  bob@test.com
// candice  19  candice@test.com

// updat alice age 20
// records where age < 20
// record add dan 22 dan@test.com
// delete candice  19  candice@test.com


//
// await user.updateOne({ email: "sara4@example.com" }, { age: 29 });

// const users = await user.find({ age: { $gt: 25 } });

// await user.deleteOne({ email: "sara4@example.com" });

// console.log({users})









// const express = require('express');
// const mongoose = require('mongoose');
// // const User = require('./models/User');


// mongoose.connect("mongodb://write_user:write@localhost:27017/newdb?authSource=admin")

// const app = express()

// app.use(express.json())

// const userSchema = new mongoose.Schema({
//   name: {
//     type: String,
//   },
//   email: {
//     type: String,
//     required: true,
//     unique: true,
//   },
//   age: {
//     type: Number,
//     min: 0,
//     max: 120,
//     required: false
//   }
// },{timestamp: true});

// const User = mongoose.model('User', userSchema)

// app.get("/users", (req, res) => {
//     User.find().then((users) => {
//         res.status(200).send(users)
//     }).catch((e) => {
//         console.log({e})
//         res.status(400).send("failed to fetch all users");
//     })
// }) 


// app.get("/user/:id", (req, res) => {
//     const id = req.params.id
//     User.findById(id).then((user) => {
//         res.status(200).send(user)
//     }).catch((e) => {
//         console.log({e})
//         res.status(400).send("failed to fetch");
//     })
// }) 


// app.post("/user", async (req, res) => {
//     console.log(req.body)
//     const user = new User(req.body);
//     user.save().then(() => {
//         console.log({user})
//         res.status(201).send(user);
//     }).catch((e) => {
//         console.log({e})
//         res.status(400).send("failed to save");
//     })
// })



// app.put("/user/:id", (req, res) => {
//     const id = req.params.id
//     const user = req.body
//     User.findByIdAndUpdate(id, user, {new:true, runValidators:true}).then((user) => {
//         console.log({user})
//         res.status(200).send(user);
//     }).catch((e) => {
//         console.log({e})
//         res.status(400).send("failed to update");
//     })
// })

// app.delete("/user/:id", (req, res) => {
//     const id = req.params.id
//     User.findByIdAndDelete(id).then((user) => {
//         console.log({user})
//         res.status(200).send(user);
//     }).catch((e) => {
//         console.log({e})
//         res.status(400).send("failed to delete");
//     })
// })



// app.listen(3000, () => { console.log("server running")})