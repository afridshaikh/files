/* 

    This is a angular module
    1) first line declares module name and accepts dependencies in [], currently we are not having any dependencies
    2) we created a new controller named UserList. first argument is name, second argument is scope variable
    3) The $scope variable can we accessed by both module (app.js) and index.html. 
        we can set values here and access it in html module.

*/


const myApp = angular.module("myApp", [])

myApp.controller("UserList", ['$scope', function ($scope) {
    $scope.users = ['John', 'Sara', "Bob", "Janice", "Alfred"]
}])
