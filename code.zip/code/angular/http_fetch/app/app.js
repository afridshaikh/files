const app = angular.module("app", [])

app.controller("App", ["$scope", "$http", function($scope, $http){
    $http.get('https://jsonplaceholder.typicode.com/users')
        .then(function(response) {
            $scope.users = response.data;
        }, function(error) {
            console.error("failed to fetch users. ", {error})
        });
}])