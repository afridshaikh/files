import json, os
import pandas as pd
import plotly.express as px
import streamlit as st

st.set_page_config(page_title='Water Quality Digital Twin',layout='wide')
st.title('Water Quality Optimization – Synthetic Digital Twin')
st.caption('Research/demo dashboard. All sensor data are synthetic.')
if not os.path.exists('reports/run_summary.json'):
    st.warning('Run `python -m wqo.pipeline --mode demo` first.')
    st.stop()
summary=json.load(open('reports/run_summary.json'))
metrics=summary['metrics']; best=summary['best_optimization']
a,b,c,d=st.columns(4)
a.metric('PINN R²',f"{metrics['R2']:.3f}"); b.metric('RMSE (mg/L)',f"{metrics['RMSE']:.3f}"); c.metric('Anomalies',f"{summary['anomaly_count']:,}"); d.metric('Best dose index',f"{best['dose_ratio']:.2f}x")
col1,col2=st.columns(2)
pred=pd.read_csv('reports/pinn_predictions.csv')
col1.plotly_chart(px.scatter(pred.sample(min(5000,len(pred)),random_state=42),x='actual',y='predicted',title='PINN: predicted vs observed',trendline='ols'),use_container_width=True)
opt=json.load(open('reports/optimization.json'))['grid']; odf=pd.DataFrame(opt)
col2.plotly_chart(px.line(odf,x='dose_ratio',y='safety_compliance',markers=True,title='Dose ratio vs safety compliance'),use_container_width=True)
if os.path.exists('reports/anomaly_results.csv'):
    adf=pd.read_csv('reports/anomaly_results.csv')
    st.subheader('Anomaly overview')
    st.dataframe(adf[adf.anomaly].head(100),use_container_width=True)
