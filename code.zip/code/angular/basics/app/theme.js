const themeToggle = angular.module("themeToggle", [])


themeToggle.controller("ThemeToggle", ["$scope", function($scope) {

    $scope.light = function() {
        $scope.color = "black"
        $scope.backgroundColor = "white"
    }

    $scope.dark = function() {
        $scope.color = "white"
        $scope.backgroundColor = "black"
    }
}])