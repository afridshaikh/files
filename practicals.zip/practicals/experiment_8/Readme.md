Aim: Build RESTful API with NodeJS, Express, MongoDB, Mongoose & Postman.

Objective:
- To create backend APIs using Express.
- To connect to MongoDB and perform CRUD operations via Mongoose.



Theory:
- What is RESTful API and how does Express simplify building it?
- How does Mongoose help in MongoDB interaction?


Code:



Conclusion: 


---------------------------------
Instructions to run code:

- Run `npm install` to install dependencies

- Run `npm start` to start server

- Use postman and import below curls. Click on import and paste these curls given below.

### Create

`curl --location 'localhost:3000/users' \
--header 'Content-Type: application/json' \
--data-raw '{
    "name": "xyz",
    "age": 30,
    "email" : "text3@text.com"
}'`


### Retrive

`curl --location 'localhost:3000/users'`


### Update

Get `_id` from Retrive step and replace it with `<ID>` in url below

`curl --location --request PUT 'localhost:3000/users/<ID>' \
--header 'Content-Type: application/json' \
--data '{
    "age":65
}'`



### Delete

Get `_id` from Retrive step and replace it with `<ID>` in url below

`curl --location --request DELETE 'localhost:3000/users/<ID>'`


