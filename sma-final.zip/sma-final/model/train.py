"""
model/train.py
==============
Trains two separate models and saves both to disk:

  model/stage1_detection.pkl   — RF+XGBoost, binary SMA detection
  model/stage2_progression.pkl — RF+XGBoost, 3-class severity prediction

Run: python model/train.py
"""

import os, json
import numpy as np
import pandas as pd
import joblib
import warnings
warnings.filterwarnings("ignore")

from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    accuracy_score, roc_auc_score, f1_score,
    classification_report
)
from xgboost import XGBClassifier

os.makedirs("model", exist_ok=True)

# ── Feature definitions ───────────────────────────────────────────
DETECTION_FEATURES = [
    "age", "gender", "smn1_copies", "smn2_copies",
    "eim_signal", "ck_level", "motor_score",
    "weakness_score", "onset_age", "family_history", "fvc_percent"
]

PROGRESSION_FEATURES = [
    "sma_type", "smn2_copies", "age_at_diagnosis",
    "time_since_diagnosis", "treatment_status",
    "motor_score", "motor_trend",
    "fvc_percent", "fvc_trend",
    "weakness_score", "bulbar_score"
]

SEVERITY_LABELS = {0: "Mild", 1: "Moderate", 2: "Severe"}


def build_rf(n_classes=2):
    return RandomForestClassifier(
        n_estimators=300,
        max_depth=14,
        class_weight="balanced",
        random_state=42,
        n_jobs=-1
    )


def build_xgb(n_classes=2):
    return XGBClassifier(
        n_estimators=300,
        max_depth=6,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        eval_metric="mlogloss" if n_classes > 2 else "logloss",
        num_class=n_classes if n_classes > 2 else None,
        objective="multi:softprob" if n_classes > 2 else "binary:logistic",
        random_state=42,
        n_jobs=-1,
        verbosity=0
    )


def train_model(X, y, features, n_classes, label):
    print(f"\n{'='*52}")
    print(f"  {label}")
    print(f"{'='*52}")
    print(f"  Samples: {len(X)}  |  Classes: {y.value_counts().to_dict()}")

    X_tr, X_te, y_tr, y_te = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )
    scaler  = StandardScaler()
    Xtr_s   = scaler.fit_transform(X_tr)
    Xte_s   = scaler.transform(X_te)

    rf  = build_rf(n_classes)
    xgb = build_xgb(n_classes)
    ens = VotingClassifier(
        estimators=[("rf", rf), ("xgb", xgb)],
        voting="soft", n_jobs=-1
    )

    best_score, best_model, best_name = 0, None, ""

    for name, m in [("RandomForest", rf), ("XGBoost", xgb), ("Ensemble", ens)]:
        print(f"\n  Training {name}...")
        m.fit(Xtr_s, y_tr)
        pred  = m.predict(Xte_s)
        proba = m.predict_proba(Xte_s)
        acc   = accuracy_score(y_te, pred)
        f1    = f1_score(y_te, pred, average="weighted")

        if n_classes == 2:
            auc = roc_auc_score(y_te, proba[:, 1])
            score = auc
            print(f"    Acc={acc*100:.2f}%  AUC={auc:.4f}  F1={f1:.4f}")
        else:
            auc = roc_auc_score(y_te, proba, multi_class="ovr", average="weighted")
            score = auc
            print(f"    Acc={acc*100:.2f}%  AUC(OvR)={auc:.4f}  F1={f1:.4f}")

        if score > best_score:
            best_score, best_model, best_name = score, m, name

    print(f"\n  Best: {best_name}  (AUC={best_score:.4f})")
    target_names = ["Healthy", "SMA"] if n_classes == 2 else ["Mild", "Moderate", "Severe"]
    print(classification_report(y_te, best_model.predict(Xte_s),
                                  target_names=target_names, digits=3))

    return best_model, scaler, best_name, round(best_score, 4), \
           round(accuracy_score(y_te, best_model.predict(Xte_s)), 4)


# ── Stage 1 ──────────────────────────────────────────────────────
def train_stage1():
    df = pd.read_csv("data/sma_detection.csv")
    X  = df[DETECTION_FEATURES]
    y  = df["sma_positive"]

    model, scaler, name, auc, acc = train_model(
        X, y, DETECTION_FEATURES, n_classes=2,
        label="Stage 1 — SMA Detection"
    )

    bundle = {
        "model":      model,
        "scaler":     scaler,
        "features":   DETECTION_FEATURES,
        "model_name": name,
        "auc":        auc,
        "accuracy":   acc,
        "task":       "detection",
    }
    joblib.dump(bundle, "model/stage1_detection.pkl")
    print("  ✅  Saved → model/stage1_detection.pkl")
    return bundle


# ── Stage 2 ──────────────────────────────────────────────────────
def train_stage2():
    df = pd.read_csv("data/sma_progression.csv")
    X  = df[PROGRESSION_FEATURES]
    y  = df["severity"]   # 0=Mild, 1=Moderate, 2=Severe

    model, scaler, name, auc, acc = train_model(
        X, y, PROGRESSION_FEATURES, n_classes=3,
        label="Stage 2 — Progression Severity"
    )

    bundle = {
        "model":      model,
        "scaler":     scaler,
        "features":   PROGRESSION_FEATURES,
        "model_name": name,
        "auc":        auc,
        "accuracy":   acc,
        "task":       "progression",
    }
    joblib.dump(bundle, "model/stage2_progression.pkl")
    print("  ✅  Saved → model/stage2_progression.pkl")
    return bundle


if __name__ == "__main__":
    b1 = train_stage1()
    b2 = train_stage2()

    print("\n" + "="*52)
    print("  SUMMARY")
    print("="*52)
    print(f"  Stage 1 ({b1['model_name']}): "
          f"AUC={b1['auc']}  Acc={b1['accuracy']*100:.1f}%")
    print(f"  Stage 2 ({b2['model_name']}): "
          f"AUC={b2['auc']}  Acc={b2['accuracy']*100:.1f}%")
    print("\n  Both models saved. Run: uvicorn api.main:app --reload")
