import json, os
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

st.set_page_config(page_title='Water Quality Digital Twin', layout='wide')
st.title('Water Quality Optimization — Pipeline Digital Twin')
st.caption('Research prototype using synthetic data. Not for operational water-safety decisions.')
if not os.path.exists('reports/run_summary.json'):
    st.warning('Run `python -m wqo.pipeline --mode demo --epochs 100` first.')
    st.stop()
with open('reports/run_summary.json') as f:
    summary = json.load(f)
metrics = summary['metrics']; best = summary['best_optimization']
a, b, c, d = st.columns(4)
a.metric('PINN R²', f"{metrics.get('R2', float('nan')):.3f}")
b.metric('RMSE (mg/L)', f"{metrics.get('RMSE', float('nan')):.3f}")
c.metric('Detected anomalies', f"{summary.get('anomaly_count', 0):,}")
d.metric('Selected dose ratio', f"{best.get('dose_ratio', float('nan')):.2f}×")

st.header('Pipeline network digital twin')
st.write('Nodes are coloured by chlorine residual. Lines represent connecting pipes; highlighted lines indicate a large estimated chlorine difference between endpoints.')
node_path, pipe_path = 'reports/digital_twin_nodes.csv', 'reports/digital_twin_pipes.csv'
if os.path.exists(node_path) and os.path.exists(pipe_path):
    nodes = pd.read_csv(node_path); pipes = pd.read_csv(pipe_path)
    fig = go.Figure()
    # Draw each pipe as a separate line segment, grouped into two traces for speed.
    lookup = nodes.set_index('node_id')
    # Separate trunk/major mains from local branches so the drawing reads like
    # a distribution schematic rather than an unweighted hairball.
    for status, color, status_label in [('NORMAL', '#8b9aaa', 'Normal estimate'), ('REVIEW', '#d94841', 'Review: chlorine gradient')]:
        for pipe_class, width, class_label in [('DISTRIBUTION_MAIN', 3.2, 'Main'), ('DISTRIBUTION_BRANCH', 1.25, 'Branch')]:
            if 'pipe_class' in pipes.columns:
                df = pipes[(pipes.estimated_status == status) & (pipes.pipe_class == pipe_class)]
            else:
                df = pipes[pipes.estimated_status == status]
            if df.empty:
                continue
            xs, ys = [], []
            for row in df.itertuples():
                if row.from_node in lookup.index and row.to_node in lookup.index:
                    xs.extend([lookup.loc[row.from_node, 'x'], lookup.loc[row.to_node, 'x'], None])
                    ys.extend([lookup.loc[row.from_node, 'y'], lookup.loc[row.to_node, 'y'], None])
            fig.add_trace(go.Scattergl(x=xs, y=ys, mode='lines',
                line=dict(color=color, width=width),
                name=f'{class_label} — {status_label}', hoverinfo='skip'))
    fig.add_trace(go.Scattergl(
        x=nodes.x, y=nodes.y, mode='markers', name='Network nodes',
        marker=dict(size=np.where(nodes.is_sensor.astype(bool), 9, 6),
                    color=nodes.chlorine_mg_l, colorscale='RdYlGn', cmin=0, cmax=0.6,
                    colorbar=dict(title='Chlorine<br>mg/L'), line=dict(width=0.5, color='#263238')),
        customdata=np.column_stack([nodes.node_id, nodes.chlorine_mg_l, nodes.pressure_bar_est,
                                    nodes.chlorine_status, nodes.pressure_status, nodes.is_sensor, nodes.get('node_type', 'JUNCTION')]),
        hovertemplate='Node %{customdata[0]} (%{customdata[6]})<br>Chlorine: %{customdata[1]:.3f} mg/L<br>Estimated pressure: %{customdata[2]:.2f} bar<br>Chlorine: %{customdata[3]}<br>Pressure: %{customdata[4]}<br>Chlorine sensor: %{customdata[5]}<extra></extra>'
    ))
    fig.update_layout(height=680, xaxis_title='Network east-west position (m)', yaxis_title='Network north-south position (m)', plot_bgcolor='#f7f9fc', paper_bgcolor='white',
                      legend=dict(orientation='h', yanchor='bottom', y=1.02, x=0), margin=dict(l=10,r=10,t=30,b=10))
    fig.update_yaxes(scaleanchor='x', scaleratio=1)
    st.plotly_chart(fig, use_container_width=True)
    st.caption(f"State snapshot: {summary.get('digital_twin_timestamp', 'unknown')} | {len(nodes)} nodes | {len(pipes)} pipes. Layout uses a structured street-grid topology with a west-side source and larger distribution mains. Synthetic geometry only; pressure and unmonitored-node chlorine are estimates, not hydraulic solver results.")
    low = nodes[nodes.chlorine_mg_l < 0.2]
    low_a, low_b, low_c = st.columns(3)
    low_a.metric('Nodes below 0.2 mg/L', len(low))
    low_b.metric('Nodes with chlorine sensors', int(nodes.is_sensor.astype(bool).sum()))
    low_c.metric('Pipes flagged for review', int((pipes.estimated_status == 'REVIEW').sum()))
    with st.expander('Node state table'):
        st.dataframe(nodes[['node_id','chlorine_mg_l','chlorine_status','pressure_bar_est','pressure_status','water_age_h','is_sensor']].sort_values('chlorine_mg_l'), use_container_width=True)
else:
    st.info('Digital-twin snapshot not found. Re-run the pipeline to generate it.')

st.header('Prediction and optimisation')
col1, col2 = st.columns(2)
pred_path = 'reports/pinn_predictions.csv'
if os.path.exists(pred_path):
    pred = pd.read_csv(pred_path)
    col1.plotly_chart(px.scatter(pred.sample(min(5000, len(pred)), random_state=42), x='actual', y='predicted',
                                 title='PINN: predicted vs observed'), use_container_width=True)
opt_path = 'reports/optimization.json'
if os.path.exists(opt_path):
    with open(opt_path) as f: opt = json.load(f)
    odf = pd.DataFrame(opt['grid'])
    if {'dose_ratio','safety_compliance'}.issubset(odf.columns):
        col2.plotly_chart(px.line(odf, x='dose_ratio', y='safety_compliance', markers=True,
                                  title='Dose ratio vs safety compliance'), use_container_width=True)

anomaly_path = 'reports/anomaly_results.csv'
if os.path.exists(anomaly_path):
    adf = pd.read_csv(anomaly_path)
    st.subheader('Anomaly overview')
    st.dataframe(adf[adf.anomaly.astype(bool)].head(100), use_container_width=True)
