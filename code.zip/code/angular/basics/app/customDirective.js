const customDirective = angular.module("customDirective", [])

customDirective.directive("simpleButton", function(){
    return {
        restrict: 'E',
        transclude: true,
        template: `
        <button class="simple-btn" 
          ng-transclude
          ng-click="click()"
          ng-mouseenter="color = 'blue'" 
          ng-mouseleave="color = 'green'"
          ng-style="{'background': color}"> 
        </button>
      `,
      link: function(scope) {
        scope.color = 'green';
        scope.click = function() {
          alert('Button clicked!'); 
        };
      }
    };
})