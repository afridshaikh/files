const app = angular.module("app", [])

app.directive('customElement', function() {
    return {
        restrict: 'E',
        template: '<h2>This is a custom directive if type element (E)</h2>'
    };
});


app.directive('customAttribute', function() {
    return {
        restrict: 'A',
        template: '<h2>This element has custom directive of type attribute (A)</h2>'
    };
});



app.directive('customClass', function() {
    return {
        restrict: 'C',
        template: '<h2>This element has custom directive of type class (C)</h2>'
    };
});



app.directive('hightlightText', function() {
    return {
        restrict: 'C',
        link: function(scope, element, attribute){

            element.on("click", function(){
                if(scope.highlighted===true){
                    scope.highlighted=false
                    element.css('background-color', 'white');
                    return
                }
                scope.highlighted=true
                element.css('background-color', 'yellow');
            })
        }
    };
});
