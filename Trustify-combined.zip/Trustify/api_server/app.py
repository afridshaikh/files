# api_server/app.py
from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import torch
import numpy as np
import pickle
import logging
from typing import Dict, Any
import json
from datetime import datetime
import redis
from functools import wraps
import traceback

# Local imports
from models.trustify_model import TrustifyModel
from preprocessing.feature_extractor import FeatureExtractor
from utils.explainer import ReviewExplainer
from utils.database import DatabaseManager
from utils.cache import PredictionCache

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class TrustifyAPI:
    """Main API class for Trustify fake review detection"""
    
    def __init__(self, config_path: str = "config/api_config.json"):
        self.app = Flask(__name__)
        self.config = self._load_config(config_path)
        
        # Initialize components
        self._initialize_components()
        
        # Configure Flask
        self._configure_flask()
        
        # Register routes
        self._register_routes()
    
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """Load configuration from JSON file"""
        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
            logger.info(f"Loaded configuration from {config_path}")
            return config
        except FileNotFoundError:
            logger.warning(f"Config file {config_path} not found, using defaults")
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Get default configuration"""
        return {
            "model": {
                "checkpoint_path": "models/checkpoints/best_model.pt",
                "vocab_size": 10000,
                "device": "cuda" if torch.cuda.is_available() else "cpu"
            },
            "api": {
                "host": "0.0.0.0",
                "port": 5000,
                "debug": False,
                "rate_limit": "100 per minute"
            },
            "cache": {
                "enabled": True,
                "redis_host": "localhost",
                "redis_port": 6379,
                "ttl": 3600
            },
            "database": {
                "enabled": True,
                "connection_string": "postgresql://user:password@localhost/trustify"
            }
        }
    
    def _initialize_components(self):
        """Initialize all system components"""
        logger.info("Initializing Trustify components...")
        
        # Set device
        self.device = torch.device(self.config['model']['device'])
        logger.info(f"Using device: {self.device}")
        
        # Load model
        self.model = self._load_model()
        self.model.eval()
        
        # Initialize feature extractor
        self.feature_extractor = FeatureExtractor()
        
        # Initialize explainer
        self.explainer = ReviewExplainer(self.model)
        
        # Initialize cache
        if self.config['cache']['enabled']:
            self.cache = PredictionCache(
                host=self.config['cache']['redis_host'],
                port=self.config['cache']['redis_port'],
                ttl=self.config['cache']['ttl']
            )
        else:
            self.cache = None
        
        # Initialize database
        if self.config['database']['enabled']:
            self.db_manager = DatabaseManager(
                connection_string=self.config['database']['connection_string']
            )
        else:
            self.db_manager = None
        
        logger.info("All components initialized successfully")
    
    def _load_model(self) -> TrustifyModel:
        """Load trained model from checkpoint"""
        checkpoint_path = self.config['model']['checkpoint_path']
        
        try:
            # Load model architecture
            model = TrustifyModel(
                vocab_size=self.config['model']['vocab_size'],
                use_apso=False  # Disable APSO for inference
            )
            
            # Load weights
            checkpoint = torch.load(checkpoint_path, map_location=self.device)
            model.load_state_dict(checkpoint['model_state_dict'])
            model.to(self.device)
            
            logger.info(f"Loaded model from {checkpoint_path}")
            return model
        
        except Exception as e:
            logger.error(f"Failed to load model: {e}")
            raise
    
    def _configure_flask(self):
        """Configure Flask application"""
        # Enable CORS
        CORS(self.app, resources={r"/api/*": {"origins": "*"}})
        
        # Rate limiting
        self.limiter = Limiter(
            get_remote_address,
            app=self.app,
            default_limits=[self.config['api']['rate_limit']],
            storage_uri="memory://",
        )
        
        # Error handlers
        @self.app.errorhandler(400)
        def bad_request(error):
            return jsonify({"error": "Bad request", "details": str(error)}), 400
        
        @self.app.errorhandler(404)
        def not_found(error):
            return jsonify({"error": "Not found"}), 404
        
        @self.app.errorhandler(429)
        def ratelimit_handler(error):
            return jsonify({
                "error": "Rate limit exceeded",
                "retry_after": error.description
            }), 429
        
        @self.app.errorhandler(500)
        def internal_error(error):
            logger.error(f"Internal server error: {error}")
            return jsonify({"error": "Internal server error"}), 500
    
    def _register_routes(self):
        """Register API routes"""
        
        @self.app.route('/api/v1/health', methods=['GET'])
        def health_check():
            """Health check endpoint"""
            return jsonify({
                "status": "healthy",
                "timestamp": datetime.utcnow().isoformat(),
                "model_loaded": self.model is not None,
                "cache_enabled": self.cache is not None,
                "database_enabled": self.db_manager is not None
            })
        
        @self.app.route('/api/v1/predict', methods=['POST'])
        @self.limiter.limit("10 per minute")
        def predict():
            """Single review prediction endpoint"""
            start_time = datetime.utcnow()
            
            try:
                # Parse request
                data = request.get_json()
                if not data:
                    return jsonify({"error": "No JSON data provided"}), 400
                
                # Validate input
                validation_errors = self._validate_prediction_input(data)
                if validation_errors:
                    return jsonify({"errors": validation_errors}), 400
                
                # Check cache
                cache_key = None
                if self.cache:
                    cache_key = self._generate_cache_key(data)
                    cached_result = self.cache.get(cache_key)
                    if cached_result:
                        logger.info("Serving from cache")
                        cached_result['cached'] = True
                        return jsonify(cached_result)
                
                # Extract features
                features = self.feature_extractor.extract_features(data)
                
                # Convert to model input
                model_input = self._prepare_model_input(features)
                
                # Make prediction
                with torch.no_grad():
                    logits, attention_weights = self.model(**model_input)
                    probabilities = torch.softmax(logits, dim=1)
                    prediction = torch.argmax(logits, dim=1).item()
                    confidence = probabilities[0, prediction].item()
                
                # Generate explanation
                explanation = self.explainer.explain(
                    features=features,
                    model_input=model_input,
                    prediction=prediction,
                    confidence=confidence,
                    attention_weights=attention_weights
                )
                
                # Prepare response
                processing_time = (datetime.utcnow() - start_time).total_seconds()
                response = {
                    "prediction": "fake" if prediction == 1 else "genuine",
                    "confidence": confidence,
                    "explanation": explanation,
                    "processing_time": processing_time,
                    "model_version": "trustify_v1.0",
                    "timestamp": start_time.isoformat(),
                    "cached": False
                }
                
                # Store in cache
                if self.cache and cache_key:
                    self.cache.set(cache_key, response)
                
                # Store in database
                if self.db_manager:
                    self.db_manager.store_prediction(
                        review_id=data.get('review_id'),
                        prediction_data=response,
                        raw_input=data
                    )
                
                return jsonify(response)
            
            except Exception as e:
                logger.error(f"Prediction error: {e}\n{traceback.format_exc()}")
                return jsonify({
                    "error": "Prediction failed",
                    "details": str(e)
                }), 500
        
        @self.app.route('/api/v1/batch_predict', methods=['POST'])
        @self.limiter.limit("50 per minute")
        def batch_predict():
            """Batch prediction endpoint"""
            start_time = datetime.utcnow()
            
            try:
                data = request.get_json()
                if not data or 'reviews' not in data:
                    return jsonify({"error": "No reviews provided"}), 400
                
                reviews = data['reviews']
                if not isinstance(reviews, list):
                    return jsonify({"error": "Reviews must be a list"}), 400
                
                if len(reviews) > 100:
                    return jsonify({"error": "Maximum 100 reviews per batch"}), 400
                
                results = []
                for review in reviews:
                    try:
                        # Use single prediction endpoint logic
                        features = self.feature_extractor.extract_features(review)
                        model_input = self._prepare_model_input(features)
                        
                        with torch.no_grad():
                            logits, _ = self.model(**model_input)
                            probabilities = torch.softmax(logits, dim=1)
                            prediction = torch.argmax(logits, dim=1).item()
                            confidence = probabilities[0, prediction].item()
                        
                        results.append({
                            "review_id": review.get('review_id'),
                            "prediction": "fake" if prediction == 1 else "genuine",
                            "confidence": confidence,
                            "success": True
                        })
                    
                    except Exception as e:
                        results.append({
                            "review_id": review.get('review_id'),
                            "error": str(e),
                            "success": False
                        })
                
                processing_time = (datetime.utcnow() - start_time).total_seconds()
                
                return jsonify({
                    "results": results,
                    "total_reviews": len(reviews),
                    "successful_predictions": sum(1 for r in results if r['success']),
                    "processing_time": processing_time
                })
            
            except Exception as e:
                logger.error(f"Batch prediction error: {e}")
                return jsonify({"error": "Batch prediction failed"}), 500
        
        @self.app.route('/api/v1/explain/<prediction_id>', methods=['GET'])
        def explain_prediction(prediction_id: str):
            """Get detailed explanation for a previous prediction"""
            try:
                if not self.db_manager:
                    return jsonify({"error": "Database not enabled"}), 503
                
                explanation = self.db_manager.get_prediction_explanation(prediction_id)
                if not explanation:
                    return jsonify({"error": "Prediction not found"}), 404
                
                return jsonify(explanation)
            
            except Exception as e:
                return jsonify({"error": str(e)}), 500
        
        @self.app.route('/api/v1/feedback', methods=['POST'])
        def submit_feedback():
            """Submit feedback on predictions"""
            try:
                data = request.get_json()
                required_fields = ['prediction_id', 'feedback', 'correct_label']
                
                if not all(field in data for field in required_fields):
                    return jsonify({"error": "Missing required fields"}), 400
                
                if self.db_manager:
                    self.db_manager.store_feedback(
                        prediction_id=data['prediction_id'],
                        feedback=data['feedback'],
                        correct_label=data['correct_label'],
                        comments=data.get('comments', '')
                    )
                
                return jsonify({"status": "feedback received"})
            
            except Exception as e:
                return jsonify({"error": str(e)}), 500
        
        @self.app.route('/api/v1/metrics', methods=['GET'])
        def get_metrics():
            """Get system metrics"""
            try:
                metrics = {
                    "system": {
                        "uptime": self._get_uptime(),
                        "memory_usage": self._get_memory_usage(),
                        "model_status": "loaded" if self.model else "not_loaded"
                    },
                    "performance": {
                        "cache_hit_rate": self.cache.get_hit_rate() if self.cache else 0,
                        "average_response_time": self._get_avg_response_time()
                    }
                }
                
                if self.db_manager:
                    db_metrics = self.db_manager.get_metrics()
                    metrics["database"] = db_metrics
                
                return jsonify(metrics)
            
            except Exception as e:
                return jsonify({"error": str(e)}), 500
    
    def _validate_prediction_input(self, data: Dict[str, Any]) -> List[str]:
        """Validate prediction input"""
        errors = []
        
        # Check required fields
        if 'review_text' not in data:
            errors.append("review_text is required")
        elif not isinstance(data['review_text'], str) or len(data['review_text'].strip()) == 0:
            errors.append("review_text must be a non-empty string")
        
        if 'rating' not in data:
            errors.append("rating is required")
        elif not isinstance(data['rating'], (int, float)) or data['rating'] < 1 or data['rating'] > 5:
            errors.append("rating must be a number between 1 and 5")
        
        # Optional field validation
        if 'platform' in data and data['platform'] not in ['amazon', 'yelp', 'tripadvisor', 'imdb']:
            errors.append("platform must be one of: amazon, yelp, tripadvisor, imdb")
        
        if 'product_category' in data and not isinstance(data['product_category'], str):
            errors.append("product_category must be a string")
        
        return errors
    
    def _generate_cache_key(self, data: Dict[str, Any]) -> str:
        """Generate cache key from input data"""
        import hashlib
        
        # Create a stable string representation
        cache_string = json.dumps(data, sort_keys=True)
        
        # Generate MD5 hash
        return hashlib.md5(cache_string.encode()).hexdigest()
    
    def _prepare_model_input(self, features: Dict[str, Any]) -> Dict[str, torch.Tensor]:
        """Prepare features for model input"""
        # This is a simplified version - actual implementation would handle
        # tokenization, padding, and conversion to tensors
        
        # For text features
        text_indices = torch.tensor(
            features.get('text_indices', [0] * 100),  # Placeholder
            dtype=torch.long
        ).unsqueeze(0).to(self.device)
        
        # For behavioral features
        behavioral_features = torch.tensor(
            features.get('behavioral_features', [0.0] * 50),
            dtype=torch.float32
        ).unsqueeze(0).to(self.device)
        
        # For contextual features
        contextual_features = torch.tensor(
            features.get('contextual_features', [0.0] * 20),
            dtype=torch.float32
        ).unsqueeze(0).to(self.device)
        
        return {
            'text_indices': text_indices,
            'behavioral_features': behavioral_features,
            'contextual_features': contextual_features
        }
    
    def _get_uptime(self) -> float:
        """Get system uptime in seconds"""
        import time
        if hasattr(self, '_start_time'):
            return time.time() - self._start_time
        return 0.0
    
    def _get_memory_usage(self) -> Dict[str, float]:
        """Get memory usage in MB"""
        import psutil
        process = psutil.Process()
        memory_info = process.memory_info()
        
        return {
            "rss_mb": memory_info.rss / 1024 / 1024,
            "vms_mb": memory_info.vms / 1024 / 1024
        }
    
    def _get_avg_response_time(self) -> float:
        """Get average response time (simplified)"""
        # In production, this would track actual response times
        return 0.15  # Placeholder
    
    def run(self):
        """Run the Flask application"""
        logger.info(f"Starting Trustify API on {self.config['api']['host']}:{self.config['api']['port']}")
        self._start_time = time.time()
        
        self.app.run(
            host=self.config['api']['host'],
            port=self.config['api']['port'],
            debug=self.config['api']['debug'],
            threaded=True
        )

# Utility modules
# api_server/utils/explainer.py
class ReviewExplainer:
    """Generate explanations for predictions"""
    
    def __init__(self, model):
        self.model = model
    
    def explain(self, features, model_input, prediction, confidence, attention_weights):
        """Generate comprehensive explanation"""
        explanation = {
            "summary": self._generate_summary(prediction, confidence),
            "key_factors": self._extract_key_factors(features, attention_weights),
            "confidence_breakdown": self._calculate_confidence_breakdown(features),
            "suggestions": self._generate_suggestions(prediction, features),
            "technical_details": self._get_technical_details(attention_weights)
        }
        
        return explanation
    
    def _generate_summary(self, prediction, confidence):
        """Generate human-readable summary"""
        if prediction == 1:  # Fake
            return f"This review has a {confidence:.1%} probability of being fake. Key indicators include suspicious linguistic patterns and behavioral anomalies."
        else:
            return f"This review appears genuine with {confidence:.1%} confidence. The content shows authentic user experience characteristics."
    
    def _extract_key_factors(self, features, attention_weights):
        """Extract key contributing factors"""
        factors = []
        
        # Text-based factors
        if features.get('text_exclamation_count', 0) > 3:
            factors.append("Excessive use of exclamation marks")
        
        if features.get('rating_extreme', 0) == 1:
            factors.append("Extreme rating (1 or 5 stars)")
        
        if features.get('reviewer_total_reviews', 0) < 3:
            factors.append("Reviewer has limited review history")
        
        # Add attention-based factors
        if attention_weights:
            text_attention = attention_weights.get('text', {})
            if text_attention:
                factors.append("Attention mechanism detected unusual text patterns")
        
        return factors
    
    def _calculate_confidence_breakdown(self, features):
        """Calculate confidence breakdown by feature category"""
        breakdown = {
            "text_analysis": 0.4,  # 40% weight
            "behavioral_analysis": 0.3,  # 30% weight
            "contextual_analysis": 0.2,  # 20% weight
            "metadata_analysis": 0.1  # 10% weight
        }
        
        # Calculate scores for each category
        text_score = self._calculate_text_score(features)
        behavioral_score = self._calculate_behavioral_score(features)
        contextual_score = self._calculate_contextual_score(features)
        metadata_score = self._calculate_metadata_score(features)
        
        return {
            "categories": breakdown,
            "scores": {
                "text": text_score,
                "behavioral": behavioral_score,
                "contextual": contextual_score,
                "metadata": metadata_score
            }
        }
    
    def _generate_suggestions(self, prediction, features):
        """Generate suggestions based on prediction"""
        suggestions = []
        
        if prediction == 1:  # If fake
            suggestions.append("Verify reviewer's purchase history")
            suggestions.append("Check for similar reviews from this reviewer")
            suggestions.append("Compare with verified purchase reviews")
        else:  # If genuine
            suggestions.append("This review appears trustworthy")
            suggestions.append("Consider highlighting this review")
            suggestions.append("Reviewer shows authentic engagement patterns")
        
        return suggestions
    
    def _get_technical_details(self, attention_weights):
        """Get technical details for advanced users"""
        return {
            "attention_distribution": self._summarize_attention(attention_weights),
            "model_version": "trustify_cnn_apso_v1.0",
            "inference_time": "~150ms"
        }
    
    def _summarize_attention(self, attention_weights):
        """Summarize attention weights"""
        summary = {}
        for layer, weights in attention_weights.items():
            if isinstance(weights, torch.Tensor):
                summary[layer] = {
                    "mean_attention": weights.mean().item(),
                    "max_attention": weights.max().item(),
                    "attention_entropy": self._calculate_entropy(weights)
                }
        return summary
    
    def _calculate_entropy(self, tensor):
        """Calculate entropy of attention distribution"""
        if tensor.dim() > 1:
            tensor = tensor.flatten()
        probs = torch.softmax(tensor, dim=0)
        entropy = -torch.sum(probs * torch.log(probs + 1e-10))
        return entropy.item()
    
    # Additional helper methods for score calculations
    def _calculate_text_score(self, features):
        """Calculate text analysis score"""
        score = 0.5  # Base score
        
        # Adjust based on linguistic features
        if features.get('flesch_reading_ease', 0) < 30:  # Very difficult to read
            score += 0.2
        
        if features.get('text_exclamation_count', 0) > 5:
            score += 0.15
        
        return min(score, 1.0)
    
    def _calculate_behavioral_score(self, features):
        """Calculate behavioral analysis score"""
        score = 0.5
        
        if features.get('reviewer_total_reviews', 0) < 2:
            score += 0.3
        
        if features.get('avg_time_between_reviews', 0) < 3600:  # Less than 1 hour
            score += 0.2
        
        return min(score, 1.0)
    
    def _calculate_contextual_score(self, features):
        """Calculate contextual analysis score"""
        score = 0.5
        
        if features.get('rating_deviation', 0) > 2:  # Very different from average
            score += 0.25
        
        return min(score, 1.0)
    
    def _calculate_metadata_score(self, features):
        """Calculate metadata analysis score"""
        score = 0.5
        
        if features.get('verified_purchase', 0) == 1:
            score -= 0.3  # Verified purchases are more trustworthy
        
        return max(score, 0.0)

# Database and Cache implementations
# api_server/utils/database.py
class DatabaseManager:
    """Manage database operations"""
    
    def __init__(self, connection_string: str):
        self.connection_string = connection_string
        self.engine = self._create_engine()
    
    def _create_engine(self):
        """Create SQLAlchemy engine"""
        from sqlalchemy import create_engine
        return create_engine(self.connection_string)
    
    def store_prediction(self, review_id, prediction_data, raw_input):
        """Store prediction in database"""
        # Implementation using SQLAlchemy
        pass
    
    def get_prediction_explanation(self, prediction_id):
        """Retrieve explanation from database"""
        # Implementation
        pass
    
    def store_feedback(self, prediction_id, feedback, correct_label, comments):
        """Store user feedback"""
        # Implementation
        pass
    
    def get_metrics(self):
        """Get database metrics"""
        # Implementation
        return {}

# api_server/utils/cache.py
class PredictionCache:
    """Redis-based prediction cache"""
    
    def __init__(self, host='localhost', port=6379, ttl=3600):
        self.redis_client = redis.Redis(host=host, port=port, decode_responses=True)
        self.ttl = ttl
    
    def get(self, key):
        """Get cached prediction"""
        cached = self.redis_client.get(key)
        if cached:
            return json.loads(cached)
        return None
    
    def set(self, key, value):
        """Cache prediction"""
        self.redis_client.setex(key, self.ttl, json.dumps(value))
    
    def get_hit_rate(self):
        """Get cache hit rate"""
        # Simplified implementation
        return 0.85  # Placeholder

# Main entry point
if __name__ == "__main__":
    import time
    
    # Create and run API
    api = TrustifyAPI(config_path="config/api_config.json")
    api.run()