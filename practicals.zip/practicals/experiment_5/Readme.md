Aim: To display Hello World using AngularJS Framework.

Objective:
- To create a simple AngularJS application.
- To use data binding in AngularJS.

Theory:
- What is AngularJS and how does it work?
- How does AngularJS use directives for binding data?


Code:



Conclusion: 


---------------------------------
Instructions to run code:

- Save the code in a file named `index.html`.

- Open the file in any modern web browser (Chrome/Firefox). `Right-click -> Open with -> Browser`

