import numpy as np, pandas as pd
from src.data_simulator import SimConfig, build_network, simulate_sensor_data
from src.preprocessing import clean_sensor_data
from src.optimizer import optimize_dose

def test_network_and_data():
    c=SimConfig(start='2025-01-01',end='2025-01-01 03:45')
    nodes,pipes=build_network(c); df,_=simulate_sensor_data(c,nodes)
    assert len(nodes)==c.nodes and len(pipes)==c.pipes
    assert df.timestamp.nunique()==16
    assert df.chlorine_mg_l.notna().sum()>0

def test_cleaning_removes_missing():
    c=SimConfig(start='2025-01-01',end='2025-01-01 03:45')
    nodes,_=build_network(c); df,_=simulate_sensor_data(c,nodes); clean=clean_sensor_data(df)
    assert clean.chlorine_mg_l.notna().all()

def test_optimizer_returns_result():
    best,grid=optimize_dose(np.array([.15,.22,.30,.42,.55]))
    assert best['dose_ratio']>=.5 and len(grid)==31
