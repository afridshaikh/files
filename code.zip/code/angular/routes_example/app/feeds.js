const feeds = angular.module("feeds", [])

feeds.controller("Feeds", ["$scope", function($scope){
    $scope.posts = "Assume! There are posts under this line"
}])