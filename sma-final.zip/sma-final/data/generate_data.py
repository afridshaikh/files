"""
data/generate_data.py
=====================
Generates two datasets:

1. data/sma_detection.csv   — Stage 1: SMA detection (binary)
   Features: age, gender, smn1_copies, smn2_copies, eim_signal,
             ck_level, motor_score, weakness_score, onset_age,
             family_history, fvc_percent
   Label: sma_positive (0/1)

2. data/sma_progression.csv — Stage 2: Progression severity (SMA patients only)
   Features: smn2_copies, fvc_percent, fvc_trend, motor_score,
             motor_trend, treatment_status, time_since_diagnosis,
             age_at_diagnosis, sma_type, weakness_score, bulbar_score
   Label: severity (0=Mild, 1=Moderate, 2=Severe)

Run: python data/generate_data.py
"""

import numpy as np
import pandas as pd
import os

np.random.seed(42)
os.makedirs("data", exist_ok=True)


# ─────────────────────────────────────────────────────────────────
# STAGE 1 — Detection dataset  (5,000 records, 40% SMA positive)
# ─────────────────────────────────────────────────────────────────
def generate_detection(n=5000):
    records = []
    for _ in range(n):
        is_sma = np.random.rand() < 0.40

        if is_sma:
            smn1 = np.random.choice([0, 1], p=[0.85, 0.15])
            smn2 = np.random.choice([1, 2, 3, 4], p=[0.15, 0.40, 0.35, 0.10])
        else:
            smn1 = np.random.choice([1, 2, 3], p=[0.05, 0.75, 0.20])
            smn2 = np.random.choice([1, 2, 3, 4], p=[0.10, 0.45, 0.35, 0.10])

        if is_sma:
            if smn2 == 1:   sma_type = 1
            elif smn2 == 2: sma_type = np.random.choice([1, 2], p=[0.3, 0.7])
            elif smn2 == 3: sma_type = np.random.choice([2, 3], p=[0.3, 0.7])
            else:           sma_type = np.random.choice([3, 4], p=[0.5, 0.5])
        else:
            sma_type = 0

        age    = np.random.randint(0, 65)
        gender = np.random.choice([0, 1])

        if is_sma:
            eim   = max(5.0,  round(np.random.normal(35 - sma_type * 4, 6), 2))
            ck    = max(20.0, round(np.random.normal(180 + sma_type * 30, 40), 1))
            motor = float(np.clip(round(np.random.normal(60 - sma_type * 12, 10), 1), 0, 100))
            weak  = float(np.clip(round(np.random.normal(4 + sma_type * 1.2, 1.2), 1), 0, 10))
            fvc   = float(np.clip(round(np.random.normal(80 - sma_type * 10, 12), 1), 10, 100))
        else:
            eim   = max(5.0,  round(np.random.normal(55, 8), 2))
            ck    = max(20.0, round(np.random.normal(100, 25), 1))
            motor = float(np.clip(round(np.random.normal(88, 8), 1), 0, 100))
            weak  = float(np.clip(round(np.random.normal(1.5, 1.0), 1), 0, 10))
            fvc   = float(np.clip(round(np.random.normal(95, 6), 1), 10, 100))

        fh = np.random.choice([0, 1], p=[0.4, 0.6] if is_sma else [0.95, 0.05])

        if is_sma:
            if sma_type == 1:   onset = round(np.random.uniform(0, 0.5), 1)
            elif sma_type == 2: onset = round(np.random.uniform(0.5, 1.5), 1)
            elif sma_type == 3: onset = round(np.random.uniform(1.5, 18), 1)
            else:               onset = round(np.random.uniform(18, 45), 1)
        else:
            onset = -1.0

        records.append({
            "age": age, "gender": gender,
            "smn1_copies": smn1, "smn2_copies": smn2,
            "eim_signal": eim, "ck_level": ck,
            "motor_score": motor, "weakness_score": weak,
            "onset_age": onset, "family_history": fh,
            "fvc_percent": fvc,
            "sma_positive": int(is_sma),
            "sma_type": sma_type
        })

    return pd.DataFrame(records)


# ─────────────────────────────────────────────────────────────────
# STAGE 2 — Progression dataset  (3,000 confirmed SMA patients)
# ─────────────────────────────────────────────────────────────────
def generate_progression(n=3000):
    """
    Progression severity is driven by:
    - SMN2 copies        (fewer = worse)
    - FVC %              (lower = worse)
    - FVC trend          (declining = worse)
    - Motor score        (lower = worse)
    - Motor trend        (declining = worse)
    - Treatment status   (treated = better prognosis)
    - Time since dx      (longer = potentially more advanced)
    - SMA type           (Type 1 = most severe)
    - Bulbar score       (lower = worse — swallowing/speech function)
    """
    records = []
    for _ in range(n):
        # SMA type distribution in confirmed patients
        sma_type = np.random.choice([1, 2, 3, 4], p=[0.20, 0.35, 0.35, 0.10])
        smn2     = np.random.choice([1, 2, 3, 4], p=[0.15, 0.40, 0.35, 0.10])

        # Age at diagnosis (type-dependent)
        if sma_type == 1:   age_dx = round(np.random.uniform(0, 0.5), 1)
        elif sma_type == 2: age_dx = round(np.random.uniform(0.5, 1.5), 1)
        elif sma_type == 3: age_dx = round(np.random.uniform(1.5, 18), 1)
        else:               age_dx = round(np.random.uniform(18, 50), 1)

        # Time since diagnosis (months)
        time_dx = round(np.random.uniform(1, 120), 1)

        # Treatment: nusinersen / risdiplam / gene therapy / none
        # Treated patients have better motor/respiratory outcomes
        treatment = np.random.choice([0, 1], p=[0.35, 0.65])  # 65% on treatment

        # Motor score — worse for higher type, improved with treatment
        base_motor = 80 - sma_type * 15 + treatment * 10
        motor      = float(np.clip(round(np.random.normal(base_motor, 10), 1), 0, 100))

        # Motor trend (% change per 6 months): negative = declining
        motor_trend = round(np.random.normal(
            -3 + treatment * 4 - sma_type * 1.5, 3), 1)  # treated → less decline

        # FVC — respiratory function
        base_fvc = 90 - sma_type * 12 + treatment * 8
        fvc      = float(np.clip(round(np.random.normal(base_fvc, 10), 1), 10, 100))

        # FVC trend (% change per 6 months)
        fvc_trend = round(np.random.normal(
            -2 + treatment * 3 - sma_type * 1.2, 2.5), 1)

        # Weakness
        weak = float(np.clip(round(np.random.normal(
            3 + sma_type * 1.5 - treatment * 0.8, 1.2), 1), 0, 10))

        # Bulbar score (0–10): swallowing/speech; lower = worse
        bulbar = float(np.clip(round(np.random.normal(
            8 - sma_type * 1.5 + treatment * 0.5, 1.5), 1), 0, 10))

        # ── Severity label ──────────────────────────────────────
        # Score is a weighted combination of the key indicators
        severity_score = (
            (1 - smn2 / 4) * 25 +            # SMN2 contribution (25%)
            (1 - fvc / 100) * 20 +            # FVC (20%)
            max(0, -fvc_trend) * 5 +          # FVC decline (10%)
            (1 - motor / 100) * 20 +          # Motor (20%)
            max(0, -motor_trend) * 3 +        # Motor decline (6%)
            (sma_type / 4) * 15 +             # SMA type (15%)
            (1 - treatment) * 10 +            # No treatment (10%)
            (1 - bulbar / 10) * 5             # Bulbar (5%)
        )
        # Add noise
        severity_score = float(np.clip(severity_score + np.random.normal(0, 3), 0, 100))

        if severity_score < 33:      severity = 0  # Mild
        elif severity_score < 65:    severity = 1  # Moderate
        else:                        severity = 2  # Severe

        records.append({
            "sma_type":            sma_type,
            "smn2_copies":         smn2,
            "age_at_diagnosis":    age_dx,
            "time_since_diagnosis":time_dx,
            "treatment_status":    treatment,
            "motor_score":         motor,
            "motor_trend":         motor_trend,
            "fvc_percent":         fvc,
            "fvc_trend":           fvc_trend,
            "weakness_score":      weak,
            "bulbar_score":        bulbar,
            "severity":            severity,          # 0=Mild, 1=Moderate, 2=Severe
            "severity_score":      round(severity_score, 1),
        })

    return pd.DataFrame(records)


# ── Main ─────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("Generating Stage 1 — Detection dataset...")
    det = generate_detection()
    det.to_csv("data/sma_detection.csv", index=False)
    print(f"  {len(det)} records | SMA+: {det['sma_positive'].sum()} ({det['sma_positive'].mean()*100:.1f}%)")
    print("  Saved → data/sma_detection.csv")

    print("\nGenerating Stage 2 — Progression dataset...")
    prog = generate_progression()
    prog.to_csv("data/sma_progression.csv", index=False)
    sev = prog["severity"].value_counts().sort_index()
    print(f"  {len(prog)} records")
    print(f"  Mild={sev.get(0,0)}  Moderate={sev.get(1,0)}  Severe={sev.get(2,0)}")
    print("  Saved → data/sma_progression.csv")

    print("\n✅  Done.")
