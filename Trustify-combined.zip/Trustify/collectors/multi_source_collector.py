# data_pipeline/collectors/multi_source_collector.py
import asyncio
import aiohttp
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import json
import logging
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)

class Platform(Enum):
    AMAZON = "amazon"
    YELP = "yelp"
    TRIPADVISOR = "tripadvisor"
    IMDB = "imdb"

@dataclass
class Review:
    platform: Platform
    review_id: str
    product_id: str
    reviewer_id: str
    review_text: str
    rating: float
    helpful_votes: int
    total_votes: int
    verified_purchase: bool
    review_date: datetime
    product_category: str
    reviewer_rank: Optional[int] = None
    metadata: Optional[Dict] = None

class MultiSourceCollector:
    """Asynchronous collector for multiple review platforms"""
    
    def __init__(self, api_keys: Dict[Platform, str], rate_limit_delay: float = 0.1):
        self.api_keys = api_keys
        self.rate_limit_delay = rate_limit_delay
        self.session = None
        
    async def __aenter__(self):
        self.session = aiohttp.ClientSession()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.session.close()
    
    async def collect_reviews(self, 
                             platforms: List[Platform],
                             product_category: str,
                             start_date: datetime,
                             end_date: datetime,
                             max_reviews: int = 1000) -> List[Review]:
        """Collect reviews from multiple platforms"""
        tasks = []
        for platform in platforms:
            task = self._collect_from_platform(
                platform, product_category, start_date, end_date, max_reviews
            )
            tasks.append(task)
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        all_reviews = []
        for platform_result in results:
            if isinstance(platform_result, Exception):
                logger.error(f"Failed to collect from platform: {platform_result}")
                continue
            all_reviews.extend(platform_result)
        
        return all_reviews
    
    async def _collect_from_platform(self, 
                                   platform: Platform,
                                   product_category: str,
                                   start_date: datetime,
                                   end_date: datetime,
                                   max_reviews: int) -> List[Review]:
        """Platform-specific collection logic"""
        if platform == Platform.AMAZON:
            return await self._collect_amazon_reviews(
                product_category, start_date, end_date, max_reviews
            )
        elif platform == Platform.YELP:
            return await self._collect_yelp_reviews(
                product_category, start_date, end_date, max_reviews
            )
        # ... other platform implementations
    
    async def _collect_amazon_reviews(self, 
                                     product_category: str,
                                     start_date: datetime,
                                     end_date: datetime,
                                     max_reviews: int) -> List[Review]:
        """Amazon-specific collection with pagination"""
        reviews = []
        page = 1
        
        while len(reviews) < max_reviews:
            url = self._build_amazon_url(product_category, page)
            
            try:
                async with self.session.get(url) as response:
                    if response.status == 200:
                        data = await response.json()
                        page_reviews = self._parse_amazon_response(data)
                        reviews.extend(page_reviews)
                        
                        # Check if we have enough reviews
                        if len(page_reviews) == 0 or len(reviews) >= max_reviews:
                            break
                        
                        # Rate limiting
                        await asyncio.sleep(self.rate_limit_delay)
                        page += 1
                    else:
                        logger.warning(f"Amazon API returned {response.status}")
                        break
            except Exception as e:
                logger.error(f"Error collecting Amazon reviews: {e}")
                break
        
        return reviews[:max_reviews]
    
    def _parse_amazon_response(self, data: Dict) -> List[Review]:
        """Parse Amazon API response"""
        reviews = []
        
        for item in data.get('reviews', []):
            try:
                review = Review(
                    platform=Platform.AMAZON,
                    review_id=item.get('reviewId'),
                    product_id=item.get('productId'),
                    reviewer_id=item.get('reviewerId'),
                    review_text=item.get('reviewText', ''),
                    rating=float(item.get('rating', 0)),
                    helpful_votes=int(item.get('helpfulVotes', 0)),
                    total_votes=int(item.get('totalVotes', 0)),
                    verified_purchase=item.get('verifiedPurchase', False),
                    review_date=datetime.fromisoformat(item.get('reviewDate')),
                    product_category=item.get('productCategory', ''),
                    metadata={
                        'vine_program': item.get('vineProgram', False),
                        'early_reviewer': item.get('earlyReviewer', False)
                    }
                )
                reviews.append(review)
            except Exception as e:
                logger.warning(f"Failed to parse review: {e}")
                continue
        
        return reviews
    
    async def _collect_yelp_reviews(self, 
                                   business_category: str,
                                   start_date: datetime,
                                   end_date: datetime,
                                   max_reviews: int) -> List[Review]:
        """Yelp Fusion API implementation"""
        # Similar implementation for Yelp
        pass