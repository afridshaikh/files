class Person {
    name: string;
    constructor(name: string) {
        this.name = name;
    }
    greet() {
        console.log(`Hello, ${this.name}`);
    }
}

class Student extends Person {
    studentId: number;
    constructor(name: string, studentId: number) {
        super(name);
        this.studentId = studentId;
    }
    showId() {
        console.log(`ID: ${this.studentId}`);
    }
}

const student = new Student("Alice", 123);
student.greet();
student.showId();
