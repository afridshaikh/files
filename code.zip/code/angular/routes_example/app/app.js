const app = angular.module("app", ["ngRoute", "feeds", "profile"])


app.config(function($routeProvider, $locationProvider){

    $locationProvider.hashPrefix('');

    $routeProvider
    .when('/feeds', {
        templateUrl: 'feeds.html',
        controller: 'Feeds'
    }).when('/profile', {
        templateUrl: 'profile.html',
        controller: 'Profile'
    }).otherwise({
        redirectTo: '/feeds'
    })

})





